﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace Exam_Management_Software
{
    public partial class frmResults : Form
    {
        public frmResults()
        {
            InitializeComponent();
        }
        private void loadResults()
        {
            DataTable dataTable = new DataTable();
            string query = "SELECT * FROM `results`";
            using(MySqlConnection con = new MySqlConnection(Modules.connString()))
            {
                con.Open();
                var cmd = new MySqlCommand();
                cmd.Connection = con;
                cmd.CommandText = query;
                MySqlDataAdapter adapter = new MySqlDataAdapter();
                adapter.SelectCommand = cmd;
                adapter.Fill(dataTable);
                con.Close();
            }
            foreach(DataRow dr in dataTable.Rows)
            {
                string rId = dr[0].ToString();
                int sId = int.Parse(dr[1].ToString());
                string marks = dr[2].ToString();
                DataTable stuDt = new DataTable();
                stuDt = Modules.getStudentById(sId);
                string sName = stuDt.Rows[0][2].ToString();
                string sRoll = stuDt.Rows[0][1].ToString();
                dgvResult.Rows.Add(rId, sName, sRoll, marks);
            }
        }
        private void frmResults_Load(object sender, EventArgs e)
        {
            loadResults();
        }
    }
}
