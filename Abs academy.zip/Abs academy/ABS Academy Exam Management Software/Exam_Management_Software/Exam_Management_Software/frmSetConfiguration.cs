﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Exam_Management_Software
{
    public partial class frmSetConfiguration : Form
    {
        public frmSetConfiguration()
        {
            InitializeComponent();
        }

        private void btnProceed_Click(object sender, EventArgs e)
        {
            frmQuestions frmQuestions = new frmQuestions(new frmAdminPanel());
            frmQuestions.ShowDialog();
        }

        public void reset()
        {
            
        }
        private void btnReset_Click(object sender, EventArgs e)
        {
            reset();
        }

        private void chkbxPasswordProtect_CheckedChanged(object sender, EventArgs e)
        {
            if(chkbxPasswordProtect.Checked)
            {
                txtbxPassword.Enabled = true;
                txtbxConfirmPassword.Enabled = true;
            }
            else
            {
                txtbxPassword.Enabled = false;
                txtbxConfirmPassword.Enabled = false;
            }
        }

        private void frmSetConfiguration_Load(object sender, EventArgs e)
        {
            chkbxPasswordProtect.Checked = false;
            chkbxPasswordProtect_CheckedChanged(null, null);
        }
    }
}
