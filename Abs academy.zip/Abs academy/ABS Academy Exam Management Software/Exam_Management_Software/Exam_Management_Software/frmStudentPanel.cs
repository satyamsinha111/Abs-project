﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Exam_Management_Software
{
    public partial class frmStudentPanel : Form
    {
        public frmStudentPanel()
        {
            InitializeComponent();
        }

        int OFFSET = 0;
        int LIMIT = 2,ans1,ans2,marks;
        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void reset()
        {
            rdbtn1OA.Checked = false;
            rdbtn1OB.Checked = false;
            rdbtn1OC.Checked = false;
            rdbtn1OD.Checked = false;
            rdbtn2OA.Checked = false;
            rdbtn2OB.Checked = false;
            rdbtn2OC.Checked = false;
            rdbtn2OD.Checked = false;
            byte[] img = (byte[])globalVar.dt.Rows[0][8];
            pictBxStudent.Image = Modules.ByteToImage(img);
            lblRoll.Text= globalVar.dt.Rows[0][1].ToString();
            lblName.Text= globalVar.dt.Rows[0][2].ToString();
            lblTime.Text = DateTime.Now.ToString("HH:mm tt");


        }

        private void changeQuestion(int OFFSET)
        {
            string query = "SELECT * FROM `questions_papers` LIMIT @limit OFFSET @offset";
            DataTable dt = new DataTable();
            using (MySqlConnection con = new MySqlConnection(Modules.connString()))
            {
                con.Open();
                var cmd = new MySqlCommand();
                cmd = con.CreateCommand();
                cmd.CommandText = query;
                cmd.Parameters.AddWithValue("@limit", LIMIT);
                cmd.Parameters.AddWithValue("@offset", OFFSET);


                MySqlDataAdapter adapter = new MySqlDataAdapter();
                adapter.SelectCommand = cmd;
                adapter.Fill(dt);
                con.Close();
            }
            if (dt.Rows.Count > 0)
            {
                rchtxtbxQOne.Text = dt.Rows[0][1].ToString();
                rchtxtbxQtwo.Text = dt.Rows[1][1].ToString();
                txtbxQ1O1.Text= dt.Rows[0][2].ToString();
                txtbxQ1O2.Text= dt.Rows[0][3].ToString();
                txtbxQ1O3.Text= dt.Rows[0][4].ToString();
                txtbxQ1O4.Text= dt.Rows[0][5].ToString();
                txtbxQ2O1.Text = dt.Rows[1][2].ToString();
                txtbxQ2O2.Text = dt.Rows[1][3].ToString();
                txtbxQ2O3.Text = dt.Rows[1][4].ToString();
                txtbxQ2O4.Text = dt.Rows[1][5].ToString();
                lblQoneId.Text= dt.Rows[0][0].ToString();
                lblQtwoId.Text = dt.Rows[1][0].ToString();
            }
            else
            {
                //submitting to server
                submitToServer();
                
            }
        }
        CultureInfo provider = CultureInfo.InvariantCulture;
        private void frmStudentPanel_Load(object sender, EventArgs e)
        {
            reset();
            changeQuestion(0);
            string[] arrayCTime = Modules.getScheduleTime();
            string H = arrayCTime[0];
            string M = arrayCTime[1];
            MessageBox.Show($"{H}:{M}");
            int timeInMillisecond = int.Parse(H) * 3600 * 1000 + int.Parse(M) * 60 * 1000;
            timerSchedule.Interval = timeInMillisecond;
            timer1.Start();
            timerSchedule.Start();
        }
        private DateTime _start = new DateTime();
        private void submitToServer()
        {
            //before submitting to the server
            int totalMarks = marks;
            string stuId = globalVar.dt.Rows[0][0].ToString();
            string insertQuery = "INSERT INTO `results`(`stu_id`, `marksObtained`, `Date`) VALUES (@stuId,@marks,@date)";
            using (MySqlConnection con = new MySqlConnection(Modules.connString()))
            {
                con.Open();
                var cmd = new MySqlCommand();
                cmd.Connection = con;
                cmd.CommandText = insertQuery;
                cmd.Parameters.AddWithValue("@stuId", stuId);
                cmd.Parameters.AddWithValue("@marks", totalMarks);
                cmd.Parameters.AddWithValue("@date", DateTime.Now.ToString());
                cmd.ExecuteNonQuery();
                con.Close();
            }
            //after submitting to the server
            MessageBox.Show("submitted to server");
            this.Hide();
            frmLogin frmLogin = new frmLogin();
            frmLogin.ShowDialog();
        }
        private void rdbtn1OB_CheckedChanged(object sender, EventArgs e)
        {
            if(rdbtn1OB.Checked)
            {
                ans1 = 2;
            }
            else
            {
                ans1 = 0;
            }
        }


        private void rdbtn1OC_CheckedChanged(object sender, EventArgs e)
        {
            if(rdbtn1OC.Checked)
            {
                ans1 = 3;
            }
            else
            {
                ans1 = 0;
            }
        }

        private void rdbtn1OD_CheckedChanged(object sender, EventArgs e)
        {
            if(rdbtn1OD.Checked)
            {
                ans1 = 4;
            }
            else
            {
                ans1 = 0;
            }
        }

        private void rdbtn2OA_CheckedChanged(object sender, EventArgs e)
        {
            if(rdbtn2OA.Checked)
            {
                ans2 = 1;
            }
            else
            {
                ans2 = 0;
            }
        }

        private void rdbtn2OB_CheckedChanged(object sender, EventArgs e)
        {
            if(rdbtn2OB.Checked)
            {
                ans2 = 2;
            }
            else
            {
                ans2 = 0;
            }
        }

        private void rdbtn2OC_CheckedChanged(object sender, EventArgs e)
        {
            if(rdbtn2OC.Checked)
            {
                ans2 = 3;
            }
            else
            {
                ans2 = 0;
            }
        }

        private void timerSchedule_Tick(object sender, EventArgs e)
        {
            submitToServer();
        }
        int hours = 0;
        int minutes = 0;
        int seconds = 0;
        private void timer1_Tick(object sender, EventArgs e)
        {
            seconds++;
            if(seconds>59)
            {
                minutes++;
                seconds = 0;
            }
            if(minutes>59)
            {
                hours++;
                minutes = 0;
            }
            lblH.Text = hours.ToString();
            lblM.Text = minutes.ToString();
            lblS.Text = seconds.ToString();
        }

        private void rdbtn2OD_CheckedChanged(object sender, EventArgs e)
        {
            if(rdbtn2OD.Checked)
            {
                ans2 = 4;
            }
            else
            {
                ans2 = 4;
            }
        }

        private void btnNxt_Click(object sender, EventArgs e)
        {
            int Q1 = int.Parse(lblQoneId.Text);
            int Q2 = int.Parse(lblQtwoId.Text);
            if (ans1 == Modules.getAns(Q1))
            {
                marks++;
            }
            if (ans2 == Modules.getAns(Q2))
            {
                marks++;
            }
            reset();
            OFFSET += 2;
            changeQuestion(OFFSET);
        }

        private void rdbtn1OA_CheckedChanged(object sender, EventArgs e)
        {
            if(rdbtn1OA.Checked)
            {
                MessageBox.Show("hi");
                ans1 = 1;
            }
            else
            {
                MessageBox.Show("hi2");
                ans1 = 0;
            }
        }
    }
}
