﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Exam_Management_Software
{
    public partial class frmAdminPanel : Form
    {
        public frmAdminPanel()
        {
            InitializeComponent();
        }

        private void frmAdminPanel_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void btnQuit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnCreateNew_Click(object sender, EventArgs e)
        {
            frmQuestions frmQuestions = new frmQuestions(this);
            frmQuestions.ShowDialog();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnDepartments_Click(object sender, EventArgs e)
        {
            frmDepartment frmDepartment = new frmDepartment(this);
            frmDepartment.ShowDialog();
        }

        private void btnStudents_Click(object sender, EventArgs e)
        {
            frmStudent frmStudent = new frmStudent(this);
            frmStudent.ShowDialog();
        }

        private void btnTeachers_Click(object sender, EventArgs e)
        {
            frmTeachers frmTeachers = new frmTeachers(this);
            frmTeachers.ShowDialog();
        }
        public void loadAdmin()
        {
            btnQuestionView_Click(null, null);
            DataTable dt = new DataTable();
            string query = "SELECT * FROM `departments`";
            string connectionString = globalVar.CONNECTION_STRING.Replace(globalVar.SERVER_PARAMS, globalVar.SERVER_IP);
            using (MySqlConnection databaseConnection = new MySqlConnection(connectionString))
            {
                databaseConnection.Open();
                MySqlCommand cmd = new MySqlCommand(query, databaseConnection);
                MySqlDataAdapter adapter = new MySqlDataAdapter();
                adapter.SelectCommand = cmd;
                adapter.Fill(dt);
                databaseConnection.Close();
            }
            lblDepartments.Text = dt.Rows.Count.ToString();
            DataTable dt2 = new DataTable();
            string query2 = "SELECT * FROM `teacher`";
            using (MySqlConnection databaseConnection = new MySqlConnection(connectionString))
            {
                databaseConnection.Open();
                MySqlCommand cmd = new MySqlCommand(query2, databaseConnection);
                MySqlDataAdapter adapter = new MySqlDataAdapter();
                adapter.SelectCommand = cmd;
                adapter.Fill(dt2);
                databaseConnection.Close();
            }
            lblTeachers.Text = dt2.Rows.Count.ToString();
            DataTable dt3 = new DataTable();
            string query3 = "SELECT * FROM `student`";
            using (MySqlConnection databaseConnection = new MySqlConnection(connectionString))
            {
                databaseConnection.Open();
                MySqlCommand cmd = new MySqlCommand(query3, databaseConnection);
                MySqlDataAdapter adapter = new MySqlDataAdapter();
                adapter.SelectCommand = cmd;
                adapter.Fill(dt3);
                databaseConnection.Close();
            }
            lblStudents.Text = dt3.Rows.Count.ToString();
            DataTable dt4 = new DataTable();
            string query4 = "SELECT * FROM `questions_papers`";
            using (MySqlConnection databaseConnection = new MySqlConnection(connectionString))
            {
                databaseConnection.Open();
                MySqlCommand cmd = new MySqlCommand(query4, databaseConnection);
                MySqlDataAdapter adapter = new MySqlDataAdapter();
                adapter.SelectCommand = cmd;
                adapter.Fill(dt4);
                databaseConnection.Close();
            }
            lblQuestions.Text = dt4.Rows.Count.ToString();

        }
        private void frmAdminPanel_Load(object sender, EventArgs e)
        {
            loadAdmin();
            this.dgvDept.RowsDefaultCellStyle.BackColor = Color.Bisque;
            this.dgvDept.AlternatingRowsDefaultCellStyle.BackColor = Color.Beige;
        }

         

        private void loadStudentgrid()
        {
            dgvDept.Rows.Clear();
            DataTable dt = new DataTable();
            string query = "SELECT * FROM `student`";
            using (MySqlConnection connection = new MySqlConnection(Modules.connString()))
            {
                connection.Open();
                var cmd = new MySqlCommand();
                cmd = connection.CreateCommand();
                cmd.CommandText = query;
                MySqlDataAdapter adapter = new MySqlDataAdapter();
                adapter.SelectCommand = cmd;
                adapter.Fill(dt);
                connection.Close();
            }
            if (dt.Rows.Count > 0)
            {
                foreach (DataRow dr in dt.Rows)
                {
                    string roll = dr[1].ToString();
                    string name = dr[2].ToString();
                    string department = Modules.getNameDepartment(int.Parse(dr[3].ToString()));
                    string mobile = dr[4].ToString();
                    string email = dr[5].ToString();
                    string password = dr[6].ToString();
                    dgvDept.Rows.Add(roll, name, department, mobile, email, password);
                }
            }
        }
        private void loadDeptGrid()
        {
            dgvDept.Rows.Clear();
            DataTable dt = new DataTable();
            dt.Rows.Clear();
            dt = Modules.getDepartmentDataSet();
            if (dt.Rows.Count > 0)
            {
                foreach (DataRow dr in dt.Rows)
                {
                    dgvDept.Rows.Add(dr[0].ToString(), dr[1].ToString());
                }
            }
        }
        private void loadTeacherGrid()
        {
            DataTable dt = new DataTable();
            dgvDept.Rows.Clear();
            string query = "SELECT * FROM teacher";
            using (MySqlConnection connection = new MySqlConnection(Modules.connString()))
            {
                connection.Open();
                var cmd = new MySqlCommand();
                cmd = connection.CreateCommand();
                cmd.CommandText = query;
                MySqlDataAdapter adapter = new MySqlDataAdapter();
                adapter.SelectCommand = cmd;
                adapter.Fill(dt);
                connection.Close();
            }
            if (dt.Rows.Count > 0)
            {
                foreach (DataRow dr in dt.Rows)
                {
                    string roll = dr[1].ToString();
                    string name = dr[2].ToString();
                    string dept = Modules.getNameDepartment(int.Parse(dr[6].ToString()));
                    string mobile = dr[4].ToString();
                    string email = dr[3].ToString();
                    string password = dr[5].ToString();
                    dgvDept.Rows.Add(roll, name, dept, mobile, email, password);
                }
            }
        }
        private void loadQuestionsGrid()
        {
            dgvDept.Rows.Clear();
            string query = "SELECT * FROM `questions_papers`";
            DataTable dt = new DataTable();
            using (MySqlConnection con = new MySqlConnection(Modules.connString()))
            {
                con.Open();
                var cmd = new MySqlCommand();
                cmd = con.CreateCommand();
                cmd.CommandText = query;
                MySqlDataAdapter adapter = new MySqlDataAdapter();
                adapter.SelectCommand = cmd;
                adapter.Fill(dt);
                con.Close();
            }
            if (dt.Rows.Count > 0)
            {
                foreach (DataRow dr in dt.Rows)
                {
                    string correct = string.Empty;
                    if (dr[6].ToString() == 1.ToString())
                    {
                        correct = dr[2].ToString();
                    }
                    else if (dr[6].ToString() == 2.ToString())
                    {
                        correct = dr[3].ToString();
                    }
                    else if (dr[6].ToString() == 3.ToString())
                    {
                        correct = dr[4].ToString();
                    }
                    else if (dr[6].ToString() == 4.ToString())
                    {
                        correct = dr[5].ToString();
                    }
                     dgvDept.Rows.Add(dr[0].ToString(), dr[1].ToString(), correct);
                }
            }
        }
        private void btnQuestionView_Click(object sender, EventArgs e)
        {
            dgvDept.Columns.Clear();
            dgvDept.AutoGenerateColumns = false;
            DataGridViewTextBoxColumn col1 = new DataGridViewTextBoxColumn();
            col1.HeaderText = "Q.Id";
            dgvDept.Columns.Add(col1);
            DataGridViewTextBoxColumn col2 = new DataGridViewTextBoxColumn();
            col2.HeaderText = "Question";
            dgvDept.Columns.Add(col2);
            DataGridViewTextBoxColumn col3 = new DataGridViewTextBoxColumn();
            col3.HeaderText = "Correct answer";
            dgvDept.Columns.Add(col3);
            loadQuestionsGrid();
        }

        private void btnDepartmentView_Click(object sender, EventArgs e)
        {
            dgvDept.Columns.Clear();
            DataGridViewTextBoxColumn col1 = new DataGridViewTextBoxColumn();
            col1.HeaderText = "Id";
            dgvDept.Columns.Add(col1);
            DataGridViewTextBoxColumn col2 = new DataGridViewTextBoxColumn();
            col2.HeaderText = "Department name";
            dgvDept.Columns.Add(col2);
            loadDeptGrid();
        }

        private void btnTeacherView_Click(object sender, EventArgs e)
        {
            dgvDept.Columns.Clear();
            dgvDept.AutoGenerateColumns = false;
            DataGridViewTextBoxColumn col1 = new DataGridViewTextBoxColumn();
            col1.HeaderText = "Id";
            dgvDept.Columns.Add(col1);
            DataGridViewTextBoxColumn col2 = new DataGridViewTextBoxColumn();
            col2.HeaderText = "Name";
            dgvDept.Columns.Add(col2);
            DataGridViewTextBoxColumn col3 = new DataGridViewTextBoxColumn();
            col3.HeaderText = "Department";
            dgvDept.Columns.Add(col3);
            DataGridViewTextBoxColumn col4 = new DataGridViewTextBoxColumn();
            col4.HeaderText = "Mobile";
            dgvDept.Columns.Add(col4);
            DataGridViewTextBoxColumn col5 = new DataGridViewTextBoxColumn();
            col5.HeaderText = "Email";
            dgvDept.Columns.Add(col5);
            DataGridViewTextBoxColumn col6 = new DataGridViewTextBoxColumn();
            col6.HeaderText = "Password";
            dgvDept.Columns.Add(col6);
            loadTeacherGrid();

        }

        private void btnStudentView_Click(object sender, EventArgs e)
        {
            dgvDept.Columns.Clear();
            dgvDept.AutoGenerateColumns = false;
            DataGridViewTextBoxColumn col1 = new DataGridViewTextBoxColumn();
            col1.HeaderText = "Roll number";
            dgvDept.Columns.Add(col1);
            DataGridViewTextBoxColumn col2 = new DataGridViewTextBoxColumn();
            col2.HeaderText = "Name";
            dgvDept.Columns.Add(col2);
            DataGridViewTextBoxColumn col3 = new DataGridViewTextBoxColumn();
            col3.HeaderText = "Department";
            dgvDept.Columns.Add(col3);
            DataGridViewTextBoxColumn col4 = new DataGridViewTextBoxColumn();
            col4.HeaderText = "Mobile";
            dgvDept.Columns.Add(col4);
            DataGridViewTextBoxColumn col5 = new DataGridViewTextBoxColumn();
            col5.HeaderText = "Email";
            dgvDept.Columns.Add(col5);
            DataGridViewTextBoxColumn col6 = new DataGridViewTextBoxColumn();
            col6.HeaderText = "Password";
            dgvDept.Columns.Add(col6);
            loadStudentgrid();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnSettings_Click(object sender, EventArgs e)
        {
            frmSettings frmSettings = new frmSettings();
            frmSettings.ShowDialog();
        }

        private void btnResults_Click(object sender, EventArgs e)
        {
            frmResults frmResults = new frmResults();
            frmResults.ShowDialog();
        }
    }
}
