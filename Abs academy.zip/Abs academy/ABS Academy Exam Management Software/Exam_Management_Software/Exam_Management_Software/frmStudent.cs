﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Exam_Management_Software
{
    public partial class frmStudent : Form
    {
        frmAdminPanel frmAdminPanel = new frmAdminPanel();
        public frmStudent(frmAdminPanel frmAdminPanel)
        {
            InitializeComponent();
            this.frmAdminPanel = frmAdminPanel;
        }

        private void checkedListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        
        private void reset()
        {
            txtbxRollNumber.Clear();
            txtbxStudentName.Clear();
            txtbxPassword.Clear();
            txtbxMobile.Clear();
            txtbxConfirmPassword.Clear();
            txtbxEmail.Clear();
            fillCombo();
            cmbbxDept.SelectedIndex = 0;
            rchtxtbxRemarks.Clear();
            pictBxStudent.Image = Properties.Resources.avatar;
            this.dgvStudent.RowsDefaultCellStyle.BackColor = Color.Bisque;
            this.dgvStudent.AlternatingRowsDefaultCellStyle.BackColor = Color.Beige;
            loadgrid();
            btnSave.Text = "Save";
            txtbxRollNumber.Enabled = true;
            frmAdminPanel.loadAdmin();
        }
        private void loadgrid()
        {
            dgvStudent.Rows.Clear();
            DataTable dt = new DataTable();
            string query = "SELECT * FROM `student`";
            using(MySqlConnection connection = new MySqlConnection(Modules.connString()))
            {
                connection.Open();
                var cmd = new MySqlCommand();
                cmd = connection.CreateCommand();
                cmd.CommandText = query;
                MySqlDataAdapter adapter = new MySqlDataAdapter();
                adapter.SelectCommand = cmd;
                adapter.Fill(dt);
                connection.Close();
            }
            if(dt.Rows.Count>0)
            {
                foreach(DataRow dr in dt.Rows)
                {
                    string roll = dr[1].ToString();
                    string name = dr[2].ToString();
                    string department = Modules.getNameDepartment(int.Parse(dr[3].ToString()));
                    string mobile = dr[4].ToString();
                    string email = dr[5].ToString();
                    string password = dr[6].ToString();
                    dgvStudent.Rows.Add(roll, name, department, mobile, email, password);
                }
            }
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            if(openFileDialog.ShowDialog()==DialogResult.OK)
            {
                pictBxStudent.Image = Image.FromFile(openFileDialog.FileName);
            }
        }
        string currentRoll = "";
        private void btnSave_Click(object sender, EventArgs e)
        {
            if(txtbxRollNumber.Text == string.Empty)
            {
                MessageBox.Show("Please enter the roll number", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if(txtbxStudentName.Text==string.Empty)
            {
                MessageBox.Show("Please enter the student name", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if(txtbxPassword.Text==string.Empty)
            {
                MessageBox.Show("Please enter the password", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (txtbxConfirmPassword.Text == string.Empty)
            {
                MessageBox.Show("Please enter the confirmation password", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if(txtbxConfirmPassword.Text!=txtbxPassword.Text)
            {
                MessageBox.Show("Password don`t match", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            
            string roll = txtbxRollNumber.Text;
            string name = txtbxStudentName.Text;
            string department = cmbbxDept.SelectedItem.ToString();
            string mobile = txtbxMobile.Text;
            string email = txtbxEmail.Text;
            string password = txtbxPassword.Text;
            string remarks = rchtxtbxRemarks.Text;
            if (btnSave.Text=="Update")
            {
                string UpdateQuery = "UPDATE `student` SET `stu_name`=@name,`stu_dept`=@dept,`stu_mobile`=@mobile,`stu_email`=@email,`stu_password`=@password,`stu_remarks`=@remarks,`stu_image`=@photo WHERE `stu_roll`=@sRoll";
                using(MySqlConnection connection = new MySqlConnection(Modules.connString()))
                {
                    connection.Open();
                    var cmd = new MySqlCommand();
                    cmd = connection.CreateCommand();
                    cmd.CommandText = UpdateQuery;
                    cmd.Parameters.AddWithValue("@name", name);
                    cmd.Parameters.AddWithValue("@dept", Modules.getIdDepartment(department));
                    cmd.Parameters.AddWithValue("@mobile", mobile);
                    cmd.Parameters.AddWithValue("@email", email);
                    cmd.Parameters.AddWithValue("@password", password);
                    cmd.Parameters.AddWithValue("@remarks", remarks);
                    cmd.Parameters.AddWithValue("@photo", Modules.ImageToByte(pictBxStudent.Image));
                    cmd.Parameters.AddWithValue("@sRoll", currentRoll);
                    cmd.ExecuteNonQuery();
                    connection.Close();
                }
                currentRoll = "";
                MessageBox.Show("Updated sucessfully", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                btnSave.Text = "Save";
                loadgrid();
                reset();
                return;

            }
            if (!Modules.isStudentUnique(txtbxRollNumber.Text))
            {
                MessageBox.Show("Roll number already exists in database", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            string query = "INSERT INTO `student`(`stu_roll`, `stu_name`, `stu_dept`, `stu_mobile`, `stu_email`, `stu_password`, `stu_remarks`, `stu_image`) VALUES (@roll,@name,@dept,@mobile,@email,@password,@remarks,@photo)";
            using(MySqlConnection connection = new MySqlConnection(Modules.connString()))
            {
                connection.Open();
                var cmd = new MySqlCommand();
                cmd = connection.CreateCommand();
                cmd.CommandText = query;
                cmd.Parameters.AddWithValue("@roll", roll);
                cmd.Parameters.AddWithValue("@name", name);
                cmd.Parameters.AddWithValue("@dept", Modules.getIdDepartment(department));
                cmd.Parameters.AddWithValue("@mobile", mobile);
                cmd.Parameters.AddWithValue("@email", email);
                cmd.Parameters.AddWithValue("@password", password);
                cmd.Parameters.AddWithValue("@remarks", remarks);
                cmd.Parameters.AddWithValue("@photo", Modules.ImageToByte(pictBxStudent.Image));
                cmd.ExecuteNonQuery();
                connection.Close();
            }
            MessageBox.Show("Saved to database", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
            loadgrid();
            reset();
        }

        private void fillCombo()
        {
            DataTable dt = new DataTable();
            dt = Modules.getDepartmentDataSet();
            cmbbxDept.Items.Clear();
            cmbbxDept.Items.Add("Please select the department");
            foreach(DataRow dr in dt.Rows)
            {
                cmbbxDept.Items.Add(dr[1].ToString());
            }
        }
        private void frmStudent_Load(object sender, EventArgs e)
        {
            fillCombo();
            cmbbxDept.SelectedIndex = 0;
            loadgrid();
            reset();
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            reset();
        }

        private void updateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            txtbxRollNumber.Enabled = false;
            currentRoll = dgvStudent.SelectedRows[0].Cells[0].Value.ToString();
            string name = dgvStudent.SelectedRows[0].Cells[1].Value.ToString();
            string department = dgvStudent.SelectedRows[0].Cells[2].Value.ToString();
            string mobile = dgvStudent.SelectedRows[0].Cells[3].Value.ToString();
            string email = dgvStudent.SelectedRows[0].Cells[4].Value.ToString();
            string password = dgvStudent.SelectedRows[0].Cells[5].Value.ToString();
            string query = "SELECT * FROM student WHERE stu_roll=@roll";
            DataTable dt = new DataTable();
            using (MySqlConnection connection = new MySqlConnection(Modules.connString()))
            {
                connection.Open();
                var cmd = new MySqlCommand();
                cmd = connection.CreateCommand();
                cmd.CommandText = query;
                cmd.Parameters.AddWithValue("@roll", currentRoll);
                MySqlDataAdapter mySqlDataAdapter = new MySqlDataAdapter();
                mySqlDataAdapter.SelectCommand = cmd;
                mySqlDataAdapter.Fill(dt);
                connection.Close();
            }
            txtbxRollNumber.Text = currentRoll;
            txtbxStudentName.Text = name;
            cmbbxDept.Text = department;
            txtbxMobile.Text = mobile;
            txtbxEmail.Text = email;
            txtbxPassword.Text = password;
            txtbxConfirmPassword.Text = password;
            rchtxtbxRemarks.Text = dt.Rows[0][7].ToString();
            byte[] img = (byte[])dt.Rows[0][8];
            pictBxStudent.Image = Modules.ByteToImage(img);
            btnSave.Text = "Update";
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string Roll = dgvStudent.SelectedRows[0].Cells[0].Value.ToString();
            string query = "DELETE FROM `student` WHERE stu_roll=@roll";
            using(MySqlConnection con = new MySqlConnection(Modules.connString()))
            {
                con.Open();
                var cmd = new MySqlCommand();
                cmd = con.CreateCommand();
                cmd.CommandText = query;
                cmd.Parameters.AddWithValue("@roll", Roll);
                cmd.ExecuteNonQuery();
                con.Close();
            }
            MessageBox.Show("Deleted successfully",Application.ProductName,MessageBoxButtons.OK,MessageBoxIcon.Information);
            reset();
        }

        private void dgvStudent_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                contextMenuStrip1.Show(dgvStudent, dgvStudent.PointToClient(Cursor.Position));
            }
        }

        private void dgvStudent_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
