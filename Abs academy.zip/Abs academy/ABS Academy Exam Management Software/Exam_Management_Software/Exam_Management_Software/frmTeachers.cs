﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Exam_Management_Software
{
    public partial class frmTeachers : Form
    {
        frmAdminPanel frmAdminPanel = new frmAdminPanel();
        public frmTeachers(frmAdminPanel frmAdminPanel)
        {
            InitializeComponent();
            this.frmAdminPanel = frmAdminPanel;
        }

        private void loadGrid()
        {
            DataTable dt = new DataTable();
            dgvTeachers.Rows.Clear();
            string query = "SELECT * FROM teacher";
            using(MySqlConnection connection = new MySqlConnection(Modules.connString()))
            {
                connection.Open();
                var cmd = new MySqlCommand();
                cmd = connection.CreateCommand();
                cmd.CommandText = query;
                MySqlDataAdapter adapter = new MySqlDataAdapter();
                adapter.SelectCommand = cmd;
                adapter.Fill(dt);
                connection.Close();
            }
            if(dt.Rows.Count>0)
            {
                foreach(DataRow dr in dt.Rows)
                {
                    string roll = dr[1].ToString();
                    string name = dr[2].ToString();
                    string dept = Modules.getNameDepartment(int.Parse(dr[6].ToString()));
                    string mobile = dr[4].ToString();
                    string email = dr[3].ToString();
                    string password = dr[5].ToString();
                    dgvTeachers.Rows.Add(roll, name, dept, mobile, email, password);
                }
            }
        }

        private void fillCombo()
        {
            DataTable dt = new DataTable();
            dt = Modules.getDepartmentDataSet();
            cmbbxDepartment.Items.Clear();
            cmbbxDepartment.Items.Add("Please select the department");
            foreach (DataRow dr in dt.Rows)
            {
                cmbbxDepartment.Items.Add(dr[1].ToString());
            }
        }

        private void reset()
        {
            fillCombo();
            cmbbxDepartment.SelectedIndex = 0;
            txtbxConfirmPassword.Clear();
            txtbxEmail.Clear();
            txtbxMobile.Clear();
            txtbxPass.Clear();
            txtbxTeachersId.Clear();
            txtbxTeachersName.Clear();
            rchtxtbxRemarks.Clear();
            pctbxTeacher.Image = Properties.Resources.avatar;
            this.dgvTeachers.RowsDefaultCellStyle.BackColor = Color.Bisque;
            this.dgvTeachers.AlternatingRowsDefaultCellStyle.BackColor = Color.Beige;
            loadGrid();
            btnSave.Text = "Save";
            txtbxTeachersId.Enabled = true;
            frmAdminPanel.loadAdmin();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if(txtbxTeachersId.Text==String.Empty)
            {
                MessageBox.Show("Please enter the teacher id", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if(txtbxTeachersName.Text==string.Empty)
            {
                MessageBox.Show("Please enter the teacher name", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (txtbxPass.Text == string.Empty)
            {
                MessageBox.Show("Please enter the password", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if(txtbxConfirmPassword.Text==string.Empty)
            {
                MessageBox.Show("Please confirm password", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if(txtbxPass.Text!=txtbxConfirmPassword.Text)
            {
                MessageBox.Show("Password don`t match", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            
            string teacherId = txtbxTeachersId.Text;
            string teacherName = txtbxTeachersName.Text;
            int teacherDepartment = Modules.getIdDepartment(cmbbxDepartment.SelectedItem.ToString());
            string mobile = txtbxMobile.Text;
            string email = txtbxEmail.Text;
            string password = txtbxPass.Text;
            string remarks = rchtxtbxRemarks.Text;
            if(btnSave.Text=="Update")
            {
               
                string queryUpdate = "UPDATE `teacher` SET `teacher_name`=@name,`teacher_email`=@email,`teacher_mobile`=@mobile,`teacher_password`=@password,`teacher_department`=@dept,`teacher_remarks`=@remarks,`teacher_photo`=@photo WHERE `teacher_customid` = @cId";
                using(MySqlConnection connection = new MySqlConnection(Modules.connString()))
                {
                    connection.Open();
                    var cmd = new MySqlCommand();
                    cmd = connection.CreateCommand();
                    cmd.CommandText = queryUpdate;
                    cmd.Parameters.AddWithValue("@name", teacherName);
                    cmd.Parameters.AddWithValue("@email", email);
                    cmd.Parameters.AddWithValue("@mobile", mobile);
                    cmd.Parameters.AddWithValue("@password", password);
                    cmd.Parameters.AddWithValue("@dept", teacherDepartment);
                    cmd.Parameters.AddWithValue("@remarks", remarks);
                    cmd.Parameters.AddWithValue("@photo", Modules.ImageToByte(pctbxTeacher.Image));
                    cmd.Parameters.AddWithValue("@cId", currentId);
                    cmd.ExecuteNonQuery();
                    connection.Close();
                }
                MessageBox.Show("Updated successfully", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                loadGrid();
                reset();
                return;
            }

            if (!Modules.isTeacherUnique(txtbxTeachersId.Text))
            {
                MessageBox.Show("Id already exists in database", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            string query = "INSERT INTO `teacher`(`teacher_customid`, `teacher_name`, `teacher_email`, `teacher_mobile`, `teacher_password`, `teacher_department`, `teacher_remarks`, `teacher_photo`) VALUES (@id,@name,@email,@mobile,@password,@dept,@remark,@photo)";
            using(MySqlConnection connection = new MySqlConnection(Modules.connString()))
            {
                connection.Open();
                var cmd = new MySqlCommand();
                cmd = connection.CreateCommand();
                cmd.CommandText = query;
                cmd.Parameters.AddWithValue("@id", teacherId);
                cmd.Parameters.AddWithValue("@name", teacherName);
                cmd.Parameters.AddWithValue("@email", email);
                cmd.Parameters.AddWithValue("@mobile", mobile);
                cmd.Parameters.AddWithValue("@password", password);
                cmd.Parameters.AddWithValue("@dept", teacherDepartment);
                cmd.Parameters.AddWithValue("@remark", remarks);
                cmd.Parameters.AddWithValue("@photo", Modules.ImageToByte(pctbxTeacher.Image));
                cmd.ExecuteNonQuery();
                connection.Close();
            }
            MessageBox.Show("Saved to database", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
            loadGrid();
            reset();
        }

        private void frmTeachers_Load(object sender, EventArgs e)
        {
            reset();
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                pctbxTeacher.Image = Image.FromFile(openFileDialog.FileName);
            }
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            reset();
        }
        string currentId = "";
        private void updateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            txtbxTeachersId.Enabled = false;
            DataTable dt = new DataTable();
            currentId = dgvTeachers.SelectedRows[0].Cells[0].Value.ToString();
            string teacher_name = dgvTeachers.SelectedRows[0].Cells[1].Value.ToString();
            string teacher_dept = dgvTeachers.SelectedRows[0].Cells[2].Value.ToString();
            string mobile = dgvTeachers.SelectedRows[0].Cells[3].Value.ToString();
            string email = dgvTeachers.SelectedRows[0].Cells[4].Value.ToString();
            string password = dgvTeachers.SelectedRows[0].Cells[5].Value.ToString();
            string query = "SELECT * FROM teacher WHERE teacher_customid=@id";
            using(MySqlConnection connection = new MySqlConnection(Modules.connString()))
            {
                connection.Open();
                var cmd = new MySqlCommand();
                cmd = connection.CreateCommand();
                cmd.CommandText = query;
                cmd.Parameters.AddWithValue("@id", currentId);
                MySqlDataAdapter adapter = new MySqlDataAdapter();
                adapter.SelectCommand = cmd;
                adapter.Fill(dt);
                connection.Close();
            }
            byte[] image = (byte[])dt.Rows[0][8];
            string remarks = dt.Rows[0][7].ToString();
            txtbxTeachersId.Text = currentId;
            txtbxTeachersName.Text = teacher_name;
            cmbbxDepartment.Text = teacher_dept;
            txtbxMobile.Text = mobile;
            txtbxEmail.Text = email;
            txtbxPass.Text = password;
            txtbxConfirmPassword.Text = password;
            rchtxtbxRemarks.Text = remarks;
            pctbxTeacher.Image = Modules.ByteToImage(image);
            btnSave.Text = "Update";
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string deleteQuery = "DELETE FROM `teacher` WHERE `teacher_customid`=@id"; 
            using(MySqlConnection connection = new MySqlConnection(Modules.connString()))
            {
                connection.Open();
                var cmd = new MySqlCommand();
                cmd = connection.CreateCommand();
                cmd.CommandText = deleteQuery;
                cmd.Parameters.AddWithValue("@id", dgvTeachers.SelectedRows[0].Cells[0].Value.ToString());
                cmd.ExecuteNonQuery();
                connection.Close();
            }
            MessageBox.Show("Deleted from database", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
            loadGrid();
            reset();
        }

        private void dgvTeachers_MouseDown(object sender, MouseEventArgs e)
        {
            if(e.Button==MouseButtons.Right)
            {
                contextMenuStrip1.Show(dgvTeachers, dgvTeachers.PointToClient(Cursor.Position));
            }
        }
    }
}
