﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Exam_Management_Software
{
    class Modules
    {
        public static bool isDepartmentUnique(string dept_name)
        {
            bool isUnique = true;
            DataTable dt = new DataTable();
            string query = "SELECT * FROM `departments` where dept_name = @name";
            string connectionString = globalVar.CONNECTION_STRING.Replace(globalVar.SERVER_PARAMS, globalVar.SERVER_IP);
            using (MySqlConnection databaseConnection = new MySqlConnection(connectionString))
            {
                databaseConnection.Open();
                MySqlCommand cmd = new MySqlCommand(query, databaseConnection);
                cmd.Parameters.AddWithValue("@name", dept_name);
                MySqlDataAdapter adapter = new MySqlDataAdapter();
                adapter.SelectCommand = cmd;
                adapter.Fill(dt);
                databaseConnection.Close();
            }
            if(dt.Rows.Count>0)
            {
                isUnique = false;
            }
            return isUnique;
        }
        public static bool isTeacherUnique2(string teacherId)
        {
            bool isUnique = true;
            DataTable dt = new DataTable();
            string query = "SELECT * FROM `teacher` where teacher_customid = @id";
            string connectionString = globalVar.CONNECTION_STRING.Replace(globalVar.SERVER_PARAMS, globalVar.SERVER_IP);
            using (MySqlConnection databaseConnection = new MySqlConnection(connectionString))
            {
                databaseConnection.Open();
                MySqlCommand cmd = new MySqlCommand(query, databaseConnection);
                cmd.Parameters.AddWithValue("@id", teacherId);
                MySqlDataAdapter adapter = new MySqlDataAdapter();
                adapter.SelectCommand = cmd;
                adapter.Fill(dt);
                databaseConnection.Close();
            }
            if (dt.Rows.Count==1)
            {
                isUnique = false;
            }
            return isUnique;
        }

        public static bool isTeacherUnique(string teacherId)
        {
            bool isUnique = true;
            DataTable dt = new DataTable();
            string query = "SELECT * FROM `teacher` where teacher_customid = @id";
            string connectionString = globalVar.CONNECTION_STRING.Replace(globalVar.SERVER_PARAMS, globalVar.SERVER_IP);
            using (MySqlConnection databaseConnection = new MySqlConnection(connectionString))
            {
                databaseConnection.Open();
                MySqlCommand cmd = new MySqlCommand(query, databaseConnection);
                cmd.Parameters.AddWithValue("@id", teacherId);
                MySqlDataAdapter adapter = new MySqlDataAdapter();
                adapter.SelectCommand = cmd;
                adapter.Fill(dt);
                databaseConnection.Close();
            }
            if (dt.Rows.Count > 0)
            {
                isUnique = false;
            }
            return isUnique;
        }
        public static bool isStudentUnique2(string stuId)
        {
            bool isUnique = true;
            DataTable dt = new DataTable();
            string query = "SELECT * FROM `student` where stu_roll = @id";
            string connectionString = globalVar.CONNECTION_STRING.Replace(globalVar.SERVER_PARAMS, globalVar.SERVER_IP);
            using (MySqlConnection databaseConnection = new MySqlConnection(connectionString))
            {
                databaseConnection.Open();
                MySqlCommand cmd = new MySqlCommand(query, databaseConnection);
                cmd.Parameters.AddWithValue("@id", stuId);
                MySqlDataAdapter adapter = new MySqlDataAdapter();
                adapter.SelectCommand = cmd;
                adapter.Fill(dt);
                databaseConnection.Close();
            }
            if (dt.Rows.Count == 1)
            {
                isUnique = false;
            }
            return isUnique;
        }

        public static bool isStudentUnique(string stuId)
        {
            bool isUnique = true;
            DataTable dt = new DataTable();
            string query = "SELECT * FROM `student` where stu_roll = @id";
            string connectionString = globalVar.CONNECTION_STRING.Replace(globalVar.SERVER_PARAMS, globalVar.SERVER_IP);
            using (MySqlConnection databaseConnection = new MySqlConnection(connectionString))
            {
                databaseConnection.Open();
                MySqlCommand cmd = new MySqlCommand(query, databaseConnection);
                cmd.Parameters.AddWithValue("@id", stuId);
                MySqlDataAdapter adapter = new MySqlDataAdapter();
                adapter.SelectCommand = cmd;
                adapter.Fill(dt);
                databaseConnection.Close();
            }
            if (dt.Rows.Count > 0)
            {
                isUnique = false;
            }
            return isUnique;
        }

        public static DataTable getDepartmentDataSet()
        {
            DataTable dt = new DataTable();
            string query = "SELECT * FROM `departments`";
            string connectionString = globalVar.CONNECTION_STRING.Replace(globalVar.SERVER_PARAMS, globalVar.SERVER_IP);
            using (MySqlConnection databaseConnection = new MySqlConnection(connectionString))
            {
                databaseConnection.Open();
                MySqlCommand cmd = new MySqlCommand(query, databaseConnection);
                MySqlDataAdapter adapter = new MySqlDataAdapter();
                adapter.SelectCommand = cmd;
                adapter.Fill(dt);
                databaseConnection.Close();
            }
            return dt;
        }

        public static int getIdDepartment(String dept)
        {
            DataTable dt = new DataTable();
            int id = 0;
            string query = "SELECT * FROM `departments` where dept_name = @name";
            string connectionString = globalVar.CONNECTION_STRING.Replace(globalVar.SERVER_PARAMS, globalVar.SERVER_IP);
            using (MySqlConnection databaseConnection = new MySqlConnection(connectionString))
            {
                databaseConnection.Open();
                MySqlCommand cmd = new MySqlCommand(query, databaseConnection);
                cmd.Parameters.AddWithValue("@name", dept);
                MySqlDataAdapter adapter = new MySqlDataAdapter();
                adapter.SelectCommand = cmd;
                adapter.Fill(dt);
                databaseConnection.Close();
            }
            id = int.Parse(dt.Rows[0][0].ToString());
            return id;
        }

        public static string getTime()
        {
            string time = null;
            string query = "SELECT * FROM `admin`";
            DataTable dt2 = new DataTable();
            using(MySqlConnection con = new MySqlConnection(Modules.connString()))
            {
                con.Open();
                var cmd = new MySqlCommand();
                cmd.Connection = con;
                cmd.CommandText = query;
                MySqlDataAdapter adapter = new MySqlDataAdapter();
                adapter.SelectCommand = cmd;
                adapter.Fill(dt2);
                con.Close();
            }
            time = dt2.Rows[0][5].ToString();
            return time;
        }

        public static String[] getScheduleTime()
        {
            string time = Modules.getTime();
            String[] timeArray = time.Split(' ');
            string countDownTime = timeArray[1];
            string[] arrayCTime = countDownTime.Split(':');
            return arrayCTime;
        }

        public static string getNameDepartment(int id)
        {
            DataTable dt = new DataTable();
            string departname = "";
            string query = "SELECT * FROM `departments` where dept_id = @id";
            string connectionString = globalVar.CONNECTION_STRING.Replace(globalVar.SERVER_PARAMS, globalVar.SERVER_IP);
            using (MySqlConnection databaseConnection = new MySqlConnection(connectionString))
            {
                databaseConnection.Open();
                MySqlCommand cmd = new MySqlCommand(query, databaseConnection);
                cmd.Parameters.AddWithValue("@id", id);
                MySqlDataAdapter adapter = new MySqlDataAdapter();
                adapter.SelectCommand = cmd;
                adapter.Fill(dt);
                databaseConnection.Close();
            }
            departname = dt.Rows[0][1].ToString();
            return departname;
        }
        public static Bitmap ByteToImage(byte[] blob)
        {
            try
            {
                MemoryStream mStream = new MemoryStream();
                byte[] pData = blob;
                mStream.Write(pData, 0, Convert.ToInt32(pData.Length));
                Bitmap bm = new Bitmap(mStream, false);
                mStream.Dispose();
                return bm;
            }
            catch
            {
                return null;
            }
           
        }

        public static byte[] ImageToByte(Image img)
        {
            try
            {
                ImageConverter converter = new ImageConverter();
                return (byte[])converter.ConvertTo(img, typeof(byte[]));
            }
            catch
            {
                return null;
            }
            
        }
        public static string connString()
        {
            return globalVar.CONNECTION_STRING.Replace(globalVar.SERVER_PARAMS, globalVar.SERVER_IP);
        }

        public static DataTable getStudentById(int id)
        {
            DataTable dataTable = new DataTable();
            string query = "SELECT * FROM `student` WHERE id = @id";
            using(MySqlConnection con = new MySqlConnection(connString()))
            {
                con.Open();
                var cmd = new MySqlCommand();
                cmd.Connection = con;
                cmd.CommandText = query;
                cmd.Parameters.AddWithValue("@id", id);
                MySqlDataAdapter adapter = new MySqlDataAdapter();
                adapter.SelectCommand = cmd;
                adapter.Fill(dataTable);
                con.Close();
            }
            return dataTable;
        }

        public static int getAns(int QId)
        {
            int answer = 0;
            string query = "SELECT * FROM  `questions_papers` WHERE id = @id";
            DataTable dt = new DataTable();
            using(MySqlConnection con = new MySqlConnection(Modules.connString()))
            {
                con.Open();
                var cmd = new MySqlCommand();
                cmd.Connection = con;
                cmd.CommandText = query;
                cmd.Parameters.AddWithValue("@id", QId);
                MySqlDataAdapter adapter = new MySqlDataAdapter();
                adapter.SelectCommand = cmd;
                adapter.Fill(dt);
                con.Close();
            }
            answer = int.Parse(dt.Rows[0][6].ToString());
            return answer;
        }
    }
}
