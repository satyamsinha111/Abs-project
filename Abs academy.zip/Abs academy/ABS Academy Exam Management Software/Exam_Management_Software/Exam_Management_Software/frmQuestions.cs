﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Exam_Management_Software
{
    public partial class frmQuestions : Form
    {
        frmAdminPanel frmAdminPanel = new frmAdminPanel();
        public frmQuestions(frmAdminPanel frmAdminPanel)
        {
            InitializeComponent();
            timerWar.Start();
            this.frmAdminPanel = frmAdminPanel;

        }

        private void timerWar_Tick(object sender, EventArgs e)
        {
            lblWar.Visible = !lblWar.Visible;
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }
        private void reset()
        {
            rchtxtbxQuestion.Clear();
            txtbxOptiona.Clear();
            txtbxOptionb.Clear();
            txtbxOptionc.Clear();
            txtbxOptiond.Clear();
            rdbtnOptiona.Checked = false;
            rdbtnOptionb.Checked = false;
            rdbtnOptionc.Checked = false;
            rdbtnOptiond.Checked = false;
            btnSave.Text = "Save";
            frmAdminPanel.loadAdmin();
        }
        private int checkRadioBoxes()
        {
            int counter = 0;
            if (rdbtnOptiona.Checked)
            {
                counter++;
            }
            if (rdbtnOptionb.Checked)
            {
                counter++;
            }
            if (rdbtnOptionc.Checked)
            {
                counter++;
            }
            if (rdbtnOptiond.Checked)
            {
                counter++;
            }
            return counter;
        }
        private int optionSelected()
        {
            int option = 0;
            if(rdbtnOptiona.Checked)
            {
                option = 1;
                return option;
            }
            if(rdbtnOptionb.Checked)
            {
                option = 2;
                return option;
            }
            if(rdbtnOptionc.Checked)
            {
                option = 3;
                return option;
            }
            if(rdbtnOptiond.Checked)
            {
                option = 4;
                return option;
            }
            return option;
        }

        private void loadGrid()
        {
            dgvQuestions.Rows.Clear();
            string query = "SELECT * FROM `questions_papers`";
            DataTable dt = new DataTable();
            using(MySqlConnection con = new MySqlConnection(Modules.connString()))
            {
                con.Open();
                var cmd = new MySqlCommand();
                cmd = con.CreateCommand();
                cmd.CommandText = query;
                MySqlDataAdapter adapter = new MySqlDataAdapter();
                adapter.SelectCommand = cmd;
                adapter.Fill(dt);
                con.Close();
            }
            if(dt.Rows.Count>0)
            {
                foreach(DataRow dr in dt.Rows)
                {
                    string correct = string.Empty;
                    if(dr[6].ToString()==1.ToString())
                    {
                        correct = dr[2].ToString();
                    }
                    else if(dr[6].ToString() == 2.ToString())
                    {
                        correct = dr[3].ToString();
                    }
                    else if (dr[6].ToString() == 3.ToString())
                    {
                        correct = dr[4].ToString();
                    }
                    else if (dr[6].ToString() == 4.ToString())
                    {
                        correct = dr[5].ToString();
                    }
                    dgvQuestions.Rows.Add(dr[0].ToString(), dr[1].ToString(), correct);
                }
            }
        }


        private void frmQuestions_Load(object sender, EventArgs e)
        {
            this.dgvQuestions.RowsDefaultCellStyle.BackColor = Color.Bisque;
            this.dgvQuestions.AlternatingRowsDefaultCellStyle.BackColor = Color.Beige;
            reset();
            loadGrid();
            frmAdminPanel.loadAdmin();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if(rchtxtbxQuestion.Text==string.Empty)
            {
                MessageBox.Show("Please enter the question", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            else if(txtbxOptiona.Text==string.Empty)
            {
                MessageBox.Show("Please enter option a", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            else if(txtbxOptionb.Text==string.Empty)
            {
                MessageBox.Show("Please enter option b", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            else if(txtbxOptionc.Text==string.Empty)
            {
                MessageBox.Show("Please enter option c", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            else if(txtbxOptiond.Text==string.Empty)
            {
                MessageBox.Show("Please enter option d", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            else if(checkRadioBoxes()!=1)
            {
                MessageBox.Show("Please check the correct answer", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            string question = rchtxtbxQuestion.Text;
            string option_a = txtbxOptiona.Text;
            string option_b = txtbxOptionb.Text;
            string option_c = txtbxOptionc.Text;
            string option_d = txtbxOptiond.Text;
            int correct = optionSelected();
            if(btnSave.Text=="Update")
            {
                string updateQuery = "UPDATE `questions_papers` SET `question`=@question,`option_a`=@option_a,`option_b`=@option_b,`option_c`=@option_c,`option_d`=@option_d,`correct`=@correct WHERE `id`=@id";
                using(MySqlConnection connection = new MySqlConnection(Modules.connString()))
                {
                    connection.Open();
                    var cmd = new MySqlCommand();
                    cmd = connection.CreateCommand();
                    cmd.CommandText = updateQuery;
                    cmd.Parameters.AddWithValue("@question", question);
                    cmd.Parameters.AddWithValue("@option_a", option_a);
                    cmd.Parameters.AddWithValue("@option_b", option_b);
                    cmd.Parameters.AddWithValue("@option_c", option_c);
                    cmd.Parameters.AddWithValue("@option_d", option_d);
                    cmd.Parameters.AddWithValue("@correct", correct);
                    cmd.Parameters.AddWithValue("@id", idToUpdate);
                    cmd.ExecuteNonQuery();
                    connection.Close();
                }
                MessageBox.Show("Updated successfully", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                reset();
                loadGrid();
                return;
            }
            string query = "INSERT INTO `questions_papers`(`question`, `option_a`, `option_b`, `option_c`, `option_d`, `correct`) VALUES (@question,@option_a,@option_b,@option_c,@option_d,@correct)";
             using(MySqlConnection con = new MySqlConnection(Modules.connString()))
            {
                con.Open();
                var cmd = new MySqlCommand();
                cmd = con.CreateCommand();
                cmd.CommandText = query;
                cmd.Parameters.AddWithValue("@question", question);
                cmd.Parameters.AddWithValue("@option_a", option_a);
                cmd.Parameters.AddWithValue("@option_b", option_b);
                cmd.Parameters.AddWithValue("@option_c", option_c);
                cmd.Parameters.AddWithValue("@option_d", option_d);
                cmd.Parameters.AddWithValue("@correct", correct);
                cmd.ExecuteNonQuery();
                con.Close();
            }
            MessageBox.Show("Saved to database", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
            reset();
            loadGrid();
        }
        string idToUpdate = string.Empty;
        private void updateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            idToUpdate = dgvQuestions.SelectedRows[0].Cells[0].Value.ToString();
            string query = "SELECT * FROM `questions_papers` WHERE `id` = @id";
            DataTable dt = new DataTable();
            using(MySqlConnection con = new MySqlConnection(Modules.connString()))
            {
                con.Open();
                var cmd = new MySqlCommand();
                cmd = con.CreateCommand();
                cmd.CommandText = query;
                cmd.Parameters.AddWithValue("@id", idToUpdate);
                MySqlDataAdapter adapter = new MySqlDataAdapter();
                adapter.SelectCommand = cmd;
                adapter.Fill(dt);
                con.Close();
            }
            string question = dt.Rows[0][1].ToString();
            string option_a = dt.Rows[0][2].ToString();
            string option_b = dt.Rows[0][3].ToString();
            string option_c = dt.Rows[0][3].ToString();
            string option_d = dt.Rows[0][3].ToString();
            string correct = "";
            if (dt.Rows[0][6].ToString() == 1.ToString())
            {
                rdbtnOptiona.Checked = true;
            }
            else if (dt.Rows[0][6].ToString() == 2.ToString())
            {
                rdbtnOptionb.Checked = true;
            }
            else if (dt.Rows[0][6].ToString() == 3.ToString())
            {
                rdbtnOptionc.Checked = true;
            }
            else if (dt.Rows[0][6].ToString() == 4.ToString())
            {
                rdbtnOptiond.Checked = true;
            }
            rchtxtbxQuestion.Text = question;
            txtbxOptiona.Text = option_a;
            txtbxOptionb.Text = option_b;
            txtbxOptionc.Text = option_c;
            txtbxOptiond.Text = option_d;
            btnSave.Text = "Update";

        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string idToDelete = dgvQuestions.SelectedRows[0].Cells[0].Value.ToString();
            string query = "DELETE FROM `questions_papers` WHERE `id`=@id";
            using(MySqlConnection connection = new MySqlConnection(Modules.connString()))
            {
                connection.Open();
                var cmd = new MySqlCommand();
                cmd = connection.CreateCommand();
                cmd.CommandText = query;
                cmd.Parameters.AddWithValue("@id", idToDelete);
                cmd.ExecuteNonQuery();
                connection.Close();
            }
            MessageBox.Show("Deleted successfully", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
            reset();
            loadGrid();
        }

        private void dgvQuestions_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                contextMenuStrip1.Show(dgvQuestions, dgvQuestions.PointToClient(Cursor.Position));
            }
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            reset();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}
