﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Exam_Management_Software
{
    public partial class frmConfigure : Form
    {
        public frmConfigure()
        {
            InitializeComponent();
        }

        bool isTested = false;

        private void btnProceed_Click(object sender, EventArgs e)
        {
            if (isTested)
            {
                this.Hide();
                frmLogin frmLogin = new frmLogin();
                frmLogin.ShowDialog();
            }
            else
            {
                MessageBox.Show("Please test the connection first", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);

            }

        }
        
        private void frmConfigure_Load(object sender, EventArgs e)
        {
            txtbxDatabaseName.Text = "abs_academy_db";
        }

        private void btnTest_Click(object sender, EventArgs e)
        {
            string serverIp = txtbxServerName.Text;
            string databaseName = txtbxDatabaseName.Text;
            globalVar.SERVER_IP = serverIp;
            string connectionString = globalVar.CONNECTION_STRING.Replace(globalVar.SERVER_PARAMS, serverIp);
            try
            {
                using (MySqlConnection databaseConnection = new MySqlConnection(connectionString))
                {


                    databaseConnection.Open();
                    if (databaseConnection.State.ToString() == "Open")
                    {
                        MessageBox.Show("Database verified", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                        isTested = true;
                    }
                    else
                    {
                        isTested = false;
                    }
                    databaseConnection.Close();
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }
    }
}
