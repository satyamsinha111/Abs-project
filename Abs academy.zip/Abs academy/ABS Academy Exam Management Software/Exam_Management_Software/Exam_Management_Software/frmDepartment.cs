﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Exam_Management_Software
{
    public partial class frmDepartment : Form
    {
        frmAdminPanel frmAdminPanel = new frmAdminPanel();
        public frmDepartment(frmAdminPanel frmAdminPanel)
        {
            InitializeComponent();
            this.frmAdminPanel = frmAdminPanel;
        }
        string currentId = "";
        private void loadGrid()
        {
            dgvDept.Rows.Clear();
            DataTable dt = new DataTable();
            dt.Rows.Clear();
            dt = Modules.getDepartmentDataSet();
            if(dt.Rows.Count>0)
            {
                foreach(DataRow dr in dt.Rows)
                {
                    dgvDept.Rows.Add(dr[0].ToString(), dr[1].ToString());
                }
            }
        }
        private void reset()
        {
            txtbxDeptName.Clear();
            loadGrid();
            this.dgvDept.RowsDefaultCellStyle.BackColor = Color.Bisque;
            this.dgvDept.AlternatingRowsDefaultCellStyle.BackColor = Color.Beige;
            frmAdminPanel.loadAdmin();
        }
        private void btnAdd_Click(object sender, EventArgs e)
        {
            if(txtbxDeptName.Text==string.Empty)
            {
                MessageBox.Show("Please enter the department name", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if(!Modules.isDepartmentUnique(txtbxDeptName.Text))
            {
                MessageBox.Show("Department name already exists in database", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if(btnAdd.BackColor==Color.Yellow)
            {
                btnAdd.BackColor = Color.FromArgb(174, 20, 56);
                string updateQuery = "UPDATE `departments` SET `dept_name`=@name WHERE `dept_id`=@id";
                using(MySqlConnection connection = new MySqlConnection(Modules.connString()))
                {
                    connection.Open();
                    var cmd = new MySqlCommand();
                    cmd = connection.CreateCommand();
                    cmd.CommandText = updateQuery;
                    cmd.Parameters.AddWithValue("@id", currentId);
                    cmd.Parameters.AddWithValue("@name", txtbxDeptName.Text);
                    cmd.ExecuteNonQuery();
                    connection.Close();
                }
                currentId = "";
                reset();
                MessageBox.Show("Updated successfully", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            string query = "INSERT INTO `departments`(`dept_name`) VALUES ( @dept_name )";
           // string connectionString = globalVar.CONNECTION_STRING.Replace(globalVar.SERVER_PARAMS, globalVar.SERVER_IP);
            using (MySqlConnection databaseConnection = new MySqlConnection(Modules.connString()))
            {
                databaseConnection.Open();
                MySqlCommand cmd = databaseConnection.CreateCommand();
                cmd.CommandText = query;
                cmd.Parameters.AddWithValue("@dept_name", txtbxDeptName.Text);
                cmd.ExecuteNonQuery();
                databaseConnection.Close();
            }
            reset();
        }

        private void frmDepartment_Load(object sender, EventArgs e)
        {
            dgvDept.Sort(dgvDept.Columns[0], ListSortDirection.Ascending);
            reset();
        }

        private void dgvDept_MouseDown(object sender, MouseEventArgs e)
        {
            if(e.Button==MouseButtons.Right)
            {
                contextMenuStrip1.Show(dgvDept, dgvDept.PointToClient(Cursor.Position)); 
            }
        }

        private void updateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string department = dgvDept.SelectedRows[0].Cells[1].Value.ToString();
            currentId = dgvDept.SelectedRows[0].Cells[0].Value.ToString();
            txtbxDeptName.Text = department;
            btnAdd.BackColor = Color.Yellow;
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string updateQuery = "DELETE FROM `departments` WHERE `dept_id`=@id";
            using (MySqlConnection connection = new MySqlConnection(Modules.connString()))
            {
                connection.Open();
                var cmd = new MySqlCommand();
                cmd = connection.CreateCommand();
                cmd.CommandText = updateQuery;
                cmd.Parameters.AddWithValue("@id", dgvDept.SelectedRows[0].Cells[0].Value.ToString());
                cmd.ExecuteNonQuery();
                connection.Close();
            }
            currentId = "";
            reset();
            MessageBox.Show("Deleted successfully", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void dgvDept_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
