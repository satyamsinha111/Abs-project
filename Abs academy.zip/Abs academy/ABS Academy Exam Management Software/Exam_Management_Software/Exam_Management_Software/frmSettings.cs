﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Exam_Management_Software
{
    public partial class frmSettings : Form
    {
        public frmSettings()
        {
            InitializeComponent();
        }

        private void reset()
        {
            pctbxAdmin.Image = Properties.Resources.avatar;
            dtpDuration.Format = DateTimePickerFormat.Time;
            dtpDuration.CustomFormat = "HH:mm tt";
            dtpDuration.ShowUpDown = true;
            updateData();
        }

        private void updateData()
        {
            string query = "SELECT * FROM `admin`";
            DataTable dt = new DataTable();
            using(MySqlConnection connection = new MySqlConnection(Modules.connString()))
            {
                connection.Open();
                var cmd = new MySqlCommand();
                cmd = connection.CreateCommand();
                cmd.CommandText = query;
                MySqlDataAdapter mySqlDataAdapter = new MySqlDataAdapter();
                mySqlDataAdapter.SelectCommand = cmd;
                mySqlDataAdapter.Fill(dt);
                connection.Close();
            }
            byte[] img = (byte[])dt.Rows[0][6];
            txtbxUser.Text = dt.Rows[0][0].ToString();
            txtbxName.Text = dt.Rows[0][1].ToString();
            txtbxMobile.Text= dt.Rows[0][2].ToString();
            txtbxEmail.Text= dt.Rows[0][3].ToString();
            txtbxPassword.Text= dt.Rows[0][4].ToString();
            txtbxConfirmPassword.Text= dt.Rows[0][4].ToString();
            dtpDuration.Value = DateTime.Parse(dt.Rows[0][5].ToString());
            pctbxAdmin.Image = Modules.ByteToImage(img);
        }

        private void frmSettings_Load(object sender, EventArgs e)
        {
            reset();
            
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if(txtbxUser.Text==string.Empty)
            {
                MessageBox.Show("Please enter the username", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if(txtbxName.Text==string.Empty)
            {
                MessageBox.Show("Please enter the name", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }    
            if(txtbxPassword.Text==string.Empty)
            {
                MessageBox.Show("Please enter the password", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if(txtbxConfirmPassword.Text==string.Empty)
            {
                MessageBox.Show("Please enter the confirm password", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if(txtbxConfirmPassword.Text!=txtbxPassword.Text)
            {
                MessageBox.Show("Password don`t match", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            string query = "UPDATE `admin` SET `Username`=@username,`Name`=@name,`Mobile`=@mobile,`Email`=@email,`Password`=@password,`Duration`=@duration,`image`=@img";
            using(MySqlConnection connection = new MySqlConnection(Modules.connString()))
            {
                connection.Open();
                var cmd = new MySqlCommand();
                cmd = connection.CreateCommand();
                cmd.CommandText = query;
                cmd.Parameters.AddWithValue("@username", txtbxUser.Text);
                cmd.Parameters.AddWithValue("@name", txtbxName.Text);
                cmd.Parameters.AddWithValue("@mobile", txtbxMobile.Text);
                cmd.Parameters.AddWithValue("@email", txtbxEmail.Text);
                cmd.Parameters.AddWithValue("@password",txtbxPassword.Text);
                cmd.Parameters.AddWithValue("@duration",dtpDuration.Value.ToString());
                cmd.Parameters.AddWithValue("@img", Modules.ImageToByte(pctbxAdmin.Image));
                cmd.ExecuteNonQuery();
                connection.Close();
            }
            MessageBox.Show("Updated successfully", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
            reset();
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            if(openFileDialog.ShowDialog()==DialogResult.OK)
            {
                pctbxAdmin.Image = Image.FromFile(openFileDialog.FileName);
            }
        }
    }
}
