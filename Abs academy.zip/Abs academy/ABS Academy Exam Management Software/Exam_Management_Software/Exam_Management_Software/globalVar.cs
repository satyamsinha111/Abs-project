﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exam_Management_Software
{
    class globalVar
    {
        public static string CONNECTION_STRING = "datasource=$serverIp$;port=3306;username=root;password=;database=abs_academy_db;";
        public static string SERVER_IP = "";
        public static string SERVER_PARAMS = "$serverIp$";
        public static DataTable dt = new DataTable();
    }
}
