﻿namespace Exam_Management_Software
{
    partial class frmStudentPanel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmStudentPanel));
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel14 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel13 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel16 = new System.Windows.Forms.Panel();
            this.panel17 = new System.Windows.Forms.Panel();
            this.label20 = new System.Windows.Forms.Label();
            this.panel12 = new System.Windows.Forms.Panel();
            this.panel15 = new System.Windows.Forms.Panel();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.panel10 = new System.Windows.Forms.Panel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.label16 = new System.Windows.Forms.Label();
            this.lblTime = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.label14 = new System.Windows.Forms.Label();
            this.lblRoll = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label13 = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.pictBxStudent = new System.Windows.Forms.PictureBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.rchtxtbxQOne = new System.Windows.Forms.RichTextBox();
            this.txtbxQ1O1 = new System.Windows.Forms.TextBox();
            this.txtbxQ1O4 = new System.Windows.Forms.TextBox();
            this.txtbxQ1O2 = new System.Windows.Forms.TextBox();
            this.txtbxQ1O3 = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblQoneId = new System.Windows.Forms.Label();
            this.rdbtn1OD = new System.Windows.Forms.RadioButton();
            this.rdbtn1OC = new System.Windows.Forms.RadioButton();
            this.rdbtn1OB = new System.Windows.Forms.RadioButton();
            this.rdbtn1OA = new System.Windows.Forms.RadioButton();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lblQtwoId = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.rdbtn2OD = new System.Windows.Forms.RadioButton();
            this.rdbtn2OC = new System.Windows.Forms.RadioButton();
            this.rdbtn2OB = new System.Windows.Forms.RadioButton();
            this.rdbtn2OA = new System.Windows.Forms.RadioButton();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.rchtxtbxQtwo = new System.Windows.Forms.RichTextBox();
            this.txtbxQ2O4 = new System.Windows.Forms.TextBox();
            this.txtbxQ2O3 = new System.Windows.Forms.TextBox();
            this.txtbxQ2O1 = new System.Windows.Forms.TextBox();
            this.txtbxQ2O2 = new System.Windows.Forms.TextBox();
            this.btnNxt = new System.Windows.Forms.Button();
            this.timerSchedule = new System.Windows.Forms.Timer(this.components);
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.lblH = new System.Windows.Forms.Label();
            this.lblM = new System.Windows.Forms.Label();
            this.lblS = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel14.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel16.SuspendLayout();
            this.panel17.SuspendLayout();
            this.panel12.SuspendLayout();
            this.panel15.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictBxStudent)).BeginInit();
            this.panel3.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(218)))), ((int)(((byte)(224)))), ((int)(((byte)(226)))));
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.panel14);
            this.panel1.Controls.Add(this.panel13);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1280, 141);
            this.panel1.TabIndex = 3;
            // 
            // panel14
            // 
            this.panel14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(61)))), ((int)(((byte)(98)))));
            this.panel14.Controls.Add(this.pictureBox1);
            this.panel14.Location = new System.Drawing.Point(0, -1);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(199, 138);
            this.panel14.TabIndex = 6;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(16, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(167, 135);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(61)))), ((int)(((byte)(98)))));
            this.panel13.Location = new System.Drawing.Point(199, -3);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(5, 143);
            this.panel13.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Lucida Sans Unicode", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(75)))), ((int)(((byte)(75)))));
            this.label2.Location = new System.Drawing.Point(223, 69);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(186, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = "Durgapur - 713 211";
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.Font = new System.Drawing.Font("Lucida Sans Unicode", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(75)))), ((int)(((byte)(75)))));
            this.label1.Location = new System.Drawing.Point(222, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(664, 36);
            this.label1.TabIndex = 1;
            this.label1.Text = "ABS Academy of Science,Technology and Management";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Gainsboro;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.panel16);
            this.panel2.Controls.Add(this.panel12);
            this.panel2.Controls.Add(this.panel10);
            this.panel2.Controls.Add(this.panel8);
            this.panel2.Controls.Add(this.panel5);
            this.panel2.Controls.Add(this.panel4);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 141);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(206, 550);
            this.panel2.TabIndex = 4;
            // 
            // panel16
            // 
            this.panel16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(170)))), ((int)(((byte)(171)))));
            this.panel16.Controls.Add(this.label25);
            this.panel16.Controls.Add(this.label21);
            this.panel16.Controls.Add(this.lblS);
            this.panel16.Controls.Add(this.lblM);
            this.panel16.Controls.Add(this.lblH);
            this.panel16.Controls.Add(this.panel17);
            this.panel16.Location = new System.Drawing.Point(1, 482);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(204, 65);
            this.panel16.TabIndex = 10;
            // 
            // panel17
            // 
            this.panel17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(75)))), ((int)(((byte)(75)))));
            this.panel17.Controls.Add(this.label20);
            this.panel17.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel17.Location = new System.Drawing.Point(0, 0);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(204, 23);
            this.panel17.TabIndex = 3;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Lucida Sans Unicode", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label20.Location = new System.Drawing.Point(51, 4);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(84, 16);
            this.label20.TabIndex = 10;
            this.label20.Text = "Count down";
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(170)))), ((int)(((byte)(171)))));
            this.panel12.Controls.Add(this.panel15);
            this.panel12.Controls.Add(this.label19);
            this.panel12.Location = new System.Drawing.Point(1, 416);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(204, 65);
            this.panel12.TabIndex = 10;
            // 
            // panel15
            // 
            this.panel15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(75)))), ((int)(((byte)(75)))));
            this.panel15.Controls.Add(this.label18);
            this.panel15.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel15.Location = new System.Drawing.Point(0, 0);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(204, 23);
            this.panel15.TabIndex = 3;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Lucida Sans Unicode", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label18.Location = new System.Drawing.Point(44, 4);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(96, 16);
            this.label18.TabIndex = 10;
            this.label18.Text = "Time duration";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Lucida Sans Unicode", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label19.Location = new System.Drawing.Point(54, 35);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(62, 18);
            this.label19.TabIndex = 2;
            this.label19.Text = "1 hour";
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(170)))), ((int)(((byte)(171)))));
            this.panel10.Controls.Add(this.panel11);
            this.panel10.Controls.Add(this.lblTime);
            this.panel10.Location = new System.Drawing.Point(1, 350);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(204, 65);
            this.panel10.TabIndex = 4;
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(75)))), ((int)(((byte)(75)))));
            this.panel11.Controls.Add(this.label16);
            this.panel11.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel11.Location = new System.Drawing.Point(0, 0);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(204, 23);
            this.panel11.TabIndex = 3;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Lucida Sans Unicode", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label16.Location = new System.Drawing.Point(53, 4);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(75, 16);
            this.label16.TabIndex = 10;
            this.label16.Text = "Login time";
            // 
            // lblTime
            // 
            this.lblTime.AutoSize = true;
            this.lblTime.Font = new System.Drawing.Font("Lucida Sans Unicode", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTime.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblTime.Location = new System.Drawing.Point(60, 35);
            this.lblTime.Name = "lblTime";
            this.lblTime.Size = new System.Drawing.Size(54, 18);
            this.lblTime.TabIndex = 2;
            this.lblTime.Text = "12:00";
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(170)))), ((int)(((byte)(171)))));
            this.panel8.Controls.Add(this.panel9);
            this.panel8.Controls.Add(this.lblRoll);
            this.panel8.Location = new System.Drawing.Point(2, 284);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(204, 65);
            this.panel8.TabIndex = 4;
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(75)))), ((int)(((byte)(75)))));
            this.panel9.Controls.Add(this.label14);
            this.panel9.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel9.Location = new System.Drawing.Point(0, 0);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(204, 23);
            this.panel9.TabIndex = 3;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Lucida Sans Unicode", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label14.Location = new System.Drawing.Point(51, 4);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(81, 16);
            this.label14.TabIndex = 10;
            this.label14.Text = "Student roll";
            // 
            // lblRoll
            // 
            this.lblRoll.AutoSize = true;
            this.lblRoll.Font = new System.Drawing.Font("Lucida Sans Unicode", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRoll.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblRoll.Location = new System.Drawing.Point(48, 34);
            this.lblRoll.Name = "lblRoll";
            this.lblRoll.Size = new System.Drawing.Size(90, 18);
            this.lblRoll.TabIndex = 2;
            this.lblRoll.Text = "BCA_1234";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(170)))), ((int)(((byte)(171)))));
            this.panel5.Controls.Add(this.panel7);
            this.panel5.Controls.Add(this.lblName);
            this.panel5.Location = new System.Drawing.Point(1, 218);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(204, 65);
            this.panel5.TabIndex = 2;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(75)))), ((int)(((byte)(75)))));
            this.panel7.Controls.Add(this.label13);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel7.Location = new System.Drawing.Point(0, 0);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(204, 23);
            this.panel7.TabIndex = 3;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Lucida Sans Unicode", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label13.Location = new System.Drawing.Point(51, 4);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(94, 16);
            this.label13.TabIndex = 10;
            this.label13.Text = "Student name";
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Font = new System.Drawing.Font("Lucida Sans Unicode", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblName.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblName.Location = new System.Drawing.Point(41, 35);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(114, 18);
            this.lblName.TabIndex = 2;
            this.lblName.Text = "Satyam sinha";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(170)))), ((int)(((byte)(171)))));
            this.panel4.Controls.Add(this.panel6);
            this.panel4.Controls.Add(this.pictBxStudent);
            this.panel4.Location = new System.Drawing.Point(0, 35);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(204, 182);
            this.panel4.TabIndex = 1;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(75)))), ((int)(((byte)(75)))));
            this.panel6.Controls.Add(this.label12);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel6.Location = new System.Drawing.Point(0, 0);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(204, 23);
            this.panel6.TabIndex = 2;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Lucida Sans Unicode", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label12.Location = new System.Drawing.Point(51, 4);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(97, 16);
            this.label12.TabIndex = 10;
            this.label12.Text = "Student photo";
            // 
            // pictBxStudent
            // 
            this.pictBxStudent.Image = global::Exam_Management_Software.Properties.Resources.avatar;
            this.pictBxStudent.Location = new System.Drawing.Point(39, 37);
            this.pictBxStudent.Name = "pictBxStudent";
            this.pictBxStudent.Size = new System.Drawing.Size(124, 134);
            this.pictBxStudent.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictBxStudent.TabIndex = 1;
            this.pictBxStudent.TabStop = false;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(117)))), ((int)(((byte)(176)))));
            this.panel3.Controls.Add(this.label3);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(204, 33);
            this.panel3.TabIndex = 0;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Lucida Sans Unicode", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label3.Location = new System.Drawing.Point(40, 8);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(133, 18);
            this.label3.TabIndex = 0;
            this.label3.Text = "Student details";
            // 
            // rchtxtbxQOne
            // 
            this.rchtxtbxQOne.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.rchtxtbxQOne.BackColor = System.Drawing.Color.Gainsboro;
            this.rchtxtbxQOne.Location = new System.Drawing.Point(27, 34);
            this.rchtxtbxQOne.Name = "rchtxtbxQOne";
            this.rchtxtbxQOne.ReadOnly = true;
            this.rchtxtbxQOne.Size = new System.Drawing.Size(984, 84);
            this.rchtxtbxQOne.TabIndex = 5;
            this.rchtxtbxQOne.Text = "";
            // 
            // txtbxQ1O1
            // 
            this.txtbxQ1O1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtbxQ1O1.BackColor = System.Drawing.Color.Gainsboro;
            this.txtbxQ1O1.Location = new System.Drawing.Point(59, 133);
            this.txtbxQ1O1.Name = "txtbxQ1O1";
            this.txtbxQ1O1.ReadOnly = true;
            this.txtbxQ1O1.Size = new System.Drawing.Size(286, 24);
            this.txtbxQ1O1.TabIndex = 6;
            // 
            // txtbxQ1O4
            // 
            this.txtbxQ1O4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtbxQ1O4.BackColor = System.Drawing.Color.Gainsboro;
            this.txtbxQ1O4.Location = new System.Drawing.Point(714, 165);
            this.txtbxQ1O4.Name = "txtbxQ1O4";
            this.txtbxQ1O4.ReadOnly = true;
            this.txtbxQ1O4.Size = new System.Drawing.Size(286, 24);
            this.txtbxQ1O4.TabIndex = 7;
            // 
            // txtbxQ1O2
            // 
            this.txtbxQ1O2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtbxQ1O2.BackColor = System.Drawing.Color.Gainsboro;
            this.txtbxQ1O2.Location = new System.Drawing.Point(59, 168);
            this.txtbxQ1O2.Name = "txtbxQ1O2";
            this.txtbxQ1O2.ReadOnly = true;
            this.txtbxQ1O2.Size = new System.Drawing.Size(286, 24);
            this.txtbxQ1O2.TabIndex = 8;
            // 
            // txtbxQ1O3
            // 
            this.txtbxQ1O3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtbxQ1O3.BackColor = System.Drawing.Color.Gainsboro;
            this.txtbxQ1O3.Location = new System.Drawing.Point(714, 135);
            this.txtbxQ1O3.Name = "txtbxQ1O3";
            this.txtbxQ1O3.ReadOnly = true;
            this.txtbxQ1O3.Size = new System.Drawing.Size(286, 24);
            this.txtbxQ1O3.TabIndex = 9;
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.lblQoneId);
            this.groupBox1.Controls.Add(this.rdbtn1OD);
            this.groupBox1.Controls.Add(this.rdbtn1OC);
            this.groupBox1.Controls.Add(this.rdbtn1OB);
            this.groupBox1.Controls.Add(this.rdbtn1OA);
            this.groupBox1.Controls.Add(this.label24);
            this.groupBox1.Controls.Add(this.label23);
            this.groupBox1.Controls.Add(this.label22);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.rchtxtbxQOne);
            this.groupBox1.Controls.Add(this.txtbxQ1O4);
            this.groupBox1.Controls.Add(this.txtbxQ1O3);
            this.groupBox1.Controls.Add(this.txtbxQ1O1);
            this.groupBox1.Controls.Add(this.txtbxQ1O2);
            this.groupBox1.Location = new System.Drawing.Point(221, 145);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1047, 214);
            this.groupBox1.TabIndex = 10;
            this.groupBox1.TabStop = false;
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // lblQoneId
            // 
            this.lblQoneId.AutoSize = true;
            this.lblQoneId.Font = new System.Drawing.Font("Lucida Sans Unicode", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQoneId.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lblQoneId.Location = new System.Drawing.Point(103, 1);
            this.lblQoneId.Name = "lblQoneId";
            this.lblQoneId.Size = new System.Drawing.Size(17, 16);
            this.lblQoneId.TabIndex = 21;
            this.lblQoneId.Text = "1";
            // 
            // rdbtn1OD
            // 
            this.rdbtn1OD.AutoSize = true;
            this.rdbtn1OD.Location = new System.Drawing.Point(667, 172);
            this.rdbtn1OD.Name = "rdbtn1OD";
            this.rdbtn1OD.Size = new System.Drawing.Size(14, 13);
            this.rdbtn1OD.TabIndex = 20;
            this.rdbtn1OD.TabStop = true;
            this.rdbtn1OD.UseVisualStyleBackColor = true;
            this.rdbtn1OD.CheckedChanged += new System.EventHandler(this.rdbtn1OD_CheckedChanged);
            // 
            // rdbtn1OC
            // 
            this.rdbtn1OC.AutoSize = true;
            this.rdbtn1OC.Location = new System.Drawing.Point(667, 141);
            this.rdbtn1OC.Name = "rdbtn1OC";
            this.rdbtn1OC.Size = new System.Drawing.Size(14, 13);
            this.rdbtn1OC.TabIndex = 19;
            this.rdbtn1OC.TabStop = true;
            this.rdbtn1OC.UseVisualStyleBackColor = true;
            this.rdbtn1OC.CheckedChanged += new System.EventHandler(this.rdbtn1OC_CheckedChanged);
            // 
            // rdbtn1OB
            // 
            this.rdbtn1OB.AutoSize = true;
            this.rdbtn1OB.Location = new System.Drawing.Point(16, 174);
            this.rdbtn1OB.Name = "rdbtn1OB";
            this.rdbtn1OB.Size = new System.Drawing.Size(14, 13);
            this.rdbtn1OB.TabIndex = 18;
            this.rdbtn1OB.TabStop = true;
            this.rdbtn1OB.UseVisualStyleBackColor = true;
            this.rdbtn1OB.CheckedChanged += new System.EventHandler(this.rdbtn1OB_CheckedChanged);
            // 
            // rdbtn1OA
            // 
            this.rdbtn1OA.AutoSize = true;
            this.rdbtn1OA.Location = new System.Drawing.Point(16, 139);
            this.rdbtn1OA.Name = "rdbtn1OA";
            this.rdbtn1OA.Size = new System.Drawing.Size(14, 13);
            this.rdbtn1OA.TabIndex = 17;
            this.rdbtn1OA.TabStop = true;
            this.rdbtn1OA.UseVisualStyleBackColor = true;
            this.rdbtn1OA.CheckedChanged += new System.EventHandler(this.rdbtn1OA_CheckedChanged);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Lucida Sans Unicode", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label24.Location = new System.Drawing.Point(680, 170);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(29, 16);
            this.label24.TabIndex = 16;
            this.label24.Text = "D) ";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Lucida Sans Unicode", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label23.Location = new System.Drawing.Point(680, 138);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(28, 16);
            this.label23.TabIndex = 15;
            this.label23.Text = "C) ";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Lucida Sans Unicode", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label22.Location = new System.Drawing.Point(29, 172);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(26, 16);
            this.label22.TabIndex = 14;
            this.label22.Text = "B) ";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Lucida Sans Unicode", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label11.Location = new System.Drawing.Point(29, 137);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(28, 16);
            this.label11.TabIndex = 13;
            this.label11.Text = "A) ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Lucida Sans Unicode", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label5.Location = new System.Drawing.Point(21, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(83, 16);
            this.label5.TabIndex = 11;
            this.label5.Text = "Question :";
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.Controls.Add(this.lblQtwoId);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.rdbtn2OD);
            this.groupBox2.Controls.Add(this.rdbtn2OC);
            this.groupBox2.Controls.Add(this.rdbtn2OB);
            this.groupBox2.Controls.Add(this.rdbtn2OA);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.rchtxtbxQtwo);
            this.groupBox2.Controls.Add(this.txtbxQ2O4);
            this.groupBox2.Controls.Add(this.txtbxQ2O3);
            this.groupBox2.Controls.Add(this.txtbxQ2O1);
            this.groupBox2.Controls.Add(this.txtbxQ2O2);
            this.groupBox2.Location = new System.Drawing.Point(221, 379);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1047, 214);
            this.groupBox2.TabIndex = 12;
            this.groupBox2.TabStop = false;
            // 
            // lblQtwoId
            // 
            this.lblQtwoId.AutoSize = true;
            this.lblQtwoId.Font = new System.Drawing.Font("Lucida Sans Unicode", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQtwoId.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lblQtwoId.Location = new System.Drawing.Point(106, 1);
            this.lblQtwoId.Name = "lblQtwoId";
            this.lblQtwoId.Size = new System.Drawing.Size(17, 16);
            this.lblQtwoId.TabIndex = 23;
            this.lblQtwoId.Text = "1";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Lucida Sans Unicode", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label6.Location = new System.Drawing.Point(24, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(83, 16);
            this.label6.TabIndex = 22;
            this.label6.Text = "Question :";
            // 
            // rdbtn2OD
            // 
            this.rdbtn2OD.AutoSize = true;
            this.rdbtn2OD.Location = new System.Drawing.Point(667, 173);
            this.rdbtn2OD.Name = "rdbtn2OD";
            this.rdbtn2OD.Size = new System.Drawing.Size(14, 13);
            this.rdbtn2OD.TabIndex = 21;
            this.rdbtn2OD.TabStop = true;
            this.rdbtn2OD.UseVisualStyleBackColor = true;
            this.rdbtn2OD.CheckedChanged += new System.EventHandler(this.rdbtn2OD_CheckedChanged);
            // 
            // rdbtn2OC
            // 
            this.rdbtn2OC.AutoSize = true;
            this.rdbtn2OC.Location = new System.Drawing.Point(667, 140);
            this.rdbtn2OC.Name = "rdbtn2OC";
            this.rdbtn2OC.Size = new System.Drawing.Size(14, 13);
            this.rdbtn2OC.TabIndex = 20;
            this.rdbtn2OC.TabStop = true;
            this.rdbtn2OC.UseVisualStyleBackColor = true;
            this.rdbtn2OC.CheckedChanged += new System.EventHandler(this.rdbtn2OC_CheckedChanged);
            // 
            // rdbtn2OB
            // 
            this.rdbtn2OB.AutoSize = true;
            this.rdbtn2OB.Location = new System.Drawing.Point(16, 175);
            this.rdbtn2OB.Name = "rdbtn2OB";
            this.rdbtn2OB.Size = new System.Drawing.Size(14, 13);
            this.rdbtn2OB.TabIndex = 19;
            this.rdbtn2OB.TabStop = true;
            this.rdbtn2OB.UseVisualStyleBackColor = true;
            this.rdbtn2OB.CheckedChanged += new System.EventHandler(this.rdbtn2OB_CheckedChanged);
            // 
            // rdbtn2OA
            // 
            this.rdbtn2OA.AutoSize = true;
            this.rdbtn2OA.Location = new System.Drawing.Point(16, 140);
            this.rdbtn2OA.Name = "rdbtn2OA";
            this.rdbtn2OA.Size = new System.Drawing.Size(14, 13);
            this.rdbtn2OA.TabIndex = 18;
            this.rdbtn2OA.TabStop = true;
            this.rdbtn2OA.UseVisualStyleBackColor = true;
            this.rdbtn2OA.CheckedChanged += new System.EventHandler(this.rdbtn2OA_CheckedChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Lucida Sans Unicode", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label10.Location = new System.Drawing.Point(680, 170);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(29, 16);
            this.label10.TabIndex = 15;
            this.label10.Text = "D) ";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Lucida Sans Unicode", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label9.Location = new System.Drawing.Point(680, 137);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(28, 16);
            this.label9.TabIndex = 14;
            this.label9.Text = "C) ";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Lucida Sans Unicode", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label8.Location = new System.Drawing.Point(29, 172);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(26, 16);
            this.label8.TabIndex = 13;
            this.label8.Text = "B) ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Lucida Sans Unicode", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label7.Location = new System.Drawing.Point(28, 137);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(28, 16);
            this.label7.TabIndex = 12;
            this.label7.Text = "A) ";
            // 
            // rchtxtbxQtwo
            // 
            this.rchtxtbxQtwo.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.rchtxtbxQtwo.BackColor = System.Drawing.Color.Gainsboro;
            this.rchtxtbxQtwo.Location = new System.Drawing.Point(27, 34);
            this.rchtxtbxQtwo.Name = "rchtxtbxQtwo";
            this.rchtxtbxQtwo.ReadOnly = true;
            this.rchtxtbxQtwo.Size = new System.Drawing.Size(984, 84);
            this.rchtxtbxQtwo.TabIndex = 5;
            this.rchtxtbxQtwo.Text = "";
            // 
            // txtbxQ2O4
            // 
            this.txtbxQ2O4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtbxQ2O4.BackColor = System.Drawing.Color.Gainsboro;
            this.txtbxQ2O4.Location = new System.Drawing.Point(714, 165);
            this.txtbxQ2O4.Name = "txtbxQ2O4";
            this.txtbxQ2O4.ReadOnly = true;
            this.txtbxQ2O4.Size = new System.Drawing.Size(286, 24);
            this.txtbxQ2O4.TabIndex = 7;
            // 
            // txtbxQ2O3
            // 
            this.txtbxQ2O3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtbxQ2O3.BackColor = System.Drawing.Color.Gainsboro;
            this.txtbxQ2O3.Location = new System.Drawing.Point(714, 135);
            this.txtbxQ2O3.Name = "txtbxQ2O3";
            this.txtbxQ2O3.ReadOnly = true;
            this.txtbxQ2O3.Size = new System.Drawing.Size(286, 24);
            this.txtbxQ2O3.TabIndex = 9;
            // 
            // txtbxQ2O1
            // 
            this.txtbxQ2O1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtbxQ2O1.BackColor = System.Drawing.Color.Gainsboro;
            this.txtbxQ2O1.Location = new System.Drawing.Point(59, 133);
            this.txtbxQ2O1.Name = "txtbxQ2O1";
            this.txtbxQ2O1.ReadOnly = true;
            this.txtbxQ2O1.Size = new System.Drawing.Size(286, 24);
            this.txtbxQ2O1.TabIndex = 6;
            // 
            // txtbxQ2O2
            // 
            this.txtbxQ2O2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtbxQ2O2.BackColor = System.Drawing.Color.Gainsboro;
            this.txtbxQ2O2.Location = new System.Drawing.Point(59, 168);
            this.txtbxQ2O2.Name = "txtbxQ2O2";
            this.txtbxQ2O2.ReadOnly = true;
            this.txtbxQ2O2.Size = new System.Drawing.Size(286, 24);
            this.txtbxQ2O2.TabIndex = 8;
            // 
            // btnNxt
            // 
            this.btnNxt.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnNxt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(175)))), ((int)(((byte)(43)))));
            this.btnNxt.FlatAppearance.BorderSize = 0;
            this.btnNxt.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNxt.Font = new System.Drawing.Font("Lucida Sans Unicode", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNxt.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(83)))), ((int)(((byte)(92)))), ((int)(((byte)(104)))));
            this.btnNxt.Location = new System.Drawing.Point(1077, 624);
            this.btnNxt.Name = "btnNxt";
            this.btnNxt.Size = new System.Drawing.Size(191, 44);
            this.btnNxt.TabIndex = 13;
            this.btnNxt.Text = "NEXT >>";
            this.btnNxt.UseVisualStyleBackColor = false;
            this.btnNxt.Click += new System.EventHandler(this.btnNxt_Click);
            // 
            // timerSchedule
            // 
            this.timerSchedule.Tick += new System.EventHandler(this.timerSchedule_Tick);
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // lblH
            // 
            this.lblH.AutoSize = true;
            this.lblH.Font = new System.Drawing.Font("Lucida Sans Unicode", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblH.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblH.Location = new System.Drawing.Point(11, 31);
            this.lblH.Name = "lblH";
            this.lblH.Size = new System.Drawing.Size(40, 25);
            this.lblH.TabIndex = 6;
            this.lblH.Text = "00";
            // 
            // lblM
            // 
            this.lblM.AutoSize = true;
            this.lblM.Font = new System.Drawing.Font("Lucida Sans Unicode", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblM.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblM.Location = new System.Drawing.Point(73, 31);
            this.lblM.Name = "lblM";
            this.lblM.Size = new System.Drawing.Size(40, 25);
            this.lblM.TabIndex = 7;
            this.lblM.Text = "00";
            // 
            // lblS
            // 
            this.lblS.AutoSize = true;
            this.lblS.Font = new System.Drawing.Font("Lucida Sans Unicode", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblS.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblS.Location = new System.Drawing.Point(136, 31);
            this.lblS.Name = "lblS";
            this.lblS.Size = new System.Drawing.Size(40, 25);
            this.lblS.TabIndex = 8;
            this.lblS.Text = "00";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Lucida Sans Unicode", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label21.Location = new System.Drawing.Point(49, 31);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(20, 25);
            this.label21.TabIndex = 9;
            this.label21.Text = ":";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Lucida Sans Unicode", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label25.Location = new System.Drawing.Point(115, 31);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(20, 25);
            this.label25.TabIndex = 10;
            this.label25.Text = ":";
            // 
            // frmStudentPanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1280, 691);
            this.Controls.Add(this.btnNxt);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Lucida Sans Unicode", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmStudentPanel";
            this.Text = "frmStudentPanel";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmStudentPanel_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel14.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel16.ResumeLayout(false);
            this.panel16.PerformLayout();
            this.panel17.ResumeLayout(false);
            this.panel17.PerformLayout();
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            this.panel15.ResumeLayout(false);
            this.panel15.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictBxStudent)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictBxStudent;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label lblTime;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label lblRoll;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.RichTextBox rchtxtbxQOne;
        private System.Windows.Forms.TextBox txtbxQ1O1;
        private System.Windows.Forms.TextBox txtbxQ1O4;
        private System.Windows.Forms.TextBox txtbxQ1O2;
        private System.Windows.Forms.TextBox txtbxQ1O3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.RichTextBox rchtxtbxQtwo;
        private System.Windows.Forms.TextBox txtbxQ2O4;
        private System.Windows.Forms.TextBox txtbxQ2O3;
        private System.Windows.Forms.TextBox txtbxQ2O1;
        private System.Windows.Forms.TextBox txtbxQ2O2;
        private System.Windows.Forms.Button btnNxt;
        private System.Windows.Forms.RadioButton rdbtn1OD;
        private System.Windows.Forms.RadioButton rdbtn1OC;
        private System.Windows.Forms.RadioButton rdbtn1OB;
        private System.Windows.Forms.RadioButton rdbtn1OA;
        private System.Windows.Forms.RadioButton rdbtn2OD;
        private System.Windows.Forms.RadioButton rdbtn2OC;
        private System.Windows.Forms.RadioButton rdbtn2OB;
        private System.Windows.Forms.RadioButton rdbtn2OA;
        private System.Windows.Forms.Label lblQoneId;
        private System.Windows.Forms.Label lblQtwoId;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Timer timerSchedule;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label lblS;
        private System.Windows.Forms.Label lblM;
        private System.Windows.Forms.Label lblH;
    }
}