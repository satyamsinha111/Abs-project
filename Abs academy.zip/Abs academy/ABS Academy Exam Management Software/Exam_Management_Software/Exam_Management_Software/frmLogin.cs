﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Exam_Management_Software
{
    public partial class frmLogin : Form
    {
        public frmLogin()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            //this.Hide();
            //frmAdminPanel frmAdminPanel = new frmAdminPanel();
            //frmAdminPanel.ShowDialog();
            if(cmbbxUserType.SelectedIndex==0)
            {
                MessageBox.Show("Please select the user type", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if(txtbxUserName.Text==string.Empty)
            {
                MessageBox.Show("Please enter the username", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if(txtbxPassword.Text==string.Empty)
            {
                MessageBox.Show("Please enter the password", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            //teacher selected
            if(cmbbxUserType.SelectedIndex==1)
            {
                string query = "SELECT * FROM `admin` WHERE Username = @user AND Password =@pass";
                DataTable dt = new DataTable();
                using(MySqlConnection con = new MySqlConnection(Modules.connString()))
                {
                    con.Open();
                    var cmd = new MySqlCommand();
                    cmd = con.CreateCommand();
                    cmd.CommandText = query;
                    cmd.Parameters.AddWithValue("@user", txtbxUserName.Text);
                    cmd.Parameters.AddWithValue("@pass", txtbxPassword.Text);
                    MySqlDataAdapter adapter = new MySqlDataAdapter();
                    adapter.SelectCommand = cmd;
                    adapter.Fill(dt);
                    con.Close();
                }
                if(dt.Rows.Count>0)
                {
                    this.Hide();
                    globalVar.dt.Clear();
                    globalVar.dt = dt;
                    frmAdminPanel frmAdminPanel = new frmAdminPanel();
                    frmAdminPanel.ShowDialog();
                }
                else
                {
                    MessageBox.Show("Wrong credentials", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
            }
            //student selected
            else if(cmbbxUserType.SelectedIndex==2)
            {
                string query = "SELECT * FROM `student` WHERE stu_roll = @user AND stu_password =@pass";
                DataTable dt = new DataTable();
                using (MySqlConnection con = new MySqlConnection(Modules.connString()))
                {
                    con.Open();
                    var cmd = new MySqlCommand();
                    cmd = con.CreateCommand();
                    cmd.CommandText = query;
                    cmd.Parameters.AddWithValue("@user", txtbxUserName.Text);
                    cmd.Parameters.AddWithValue("@pass", txtbxPassword.Text);
                    MySqlDataAdapter adapter = new MySqlDataAdapter();
                    adapter.SelectCommand = cmd;
                    adapter.Fill(dt);
                    con.Close();
                }
                if (dt.Rows.Count > 0)
                {
                    this.Hide();
                    globalVar.dt.Clear();
                    globalVar.dt = dt;
                    frmStudentPanel frmStudentPanel = new frmStudentPanel();
                    frmStudentPanel.ShowDialog();
                }
                else
                {
                    MessageBox.Show("Wrong credentials", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
            }
        }

        private void frmLogin_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void frmLogin_Load(object sender, EventArgs e)
        {
            cmbbxUserType.SelectedIndex = 0;
        }
    }
}
