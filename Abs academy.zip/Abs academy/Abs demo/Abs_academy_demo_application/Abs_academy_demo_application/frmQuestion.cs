﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Abs_academy_demo_application
{
    public partial class frmQuestion : Form
    {
        frmAdmin frmAdmin = new frmAdmin();
        public frmQuestion(frmAdmin frmAdmin)
        {
            InitializeComponent();
            this.frmAdmin = frmAdmin;
        }

        private void frmQuestion_Load(object sender, EventArgs e)
        {

        }

        private void reset()
        {
            txtbxOptionB.Clear();
            txtbxOptionA.Clear();
            txtbxOptD.Clear();
            txtbxOptC.Clear();
            rchtxtbxQuestion.Clear();
            rdbtnA.Checked = false;
            rdbtnB.Checked = false;
            rdbtnC.Checked = false;
            rdbtnD.Checked = false;
        }

        private int optionSelected()
        {
            int option = 0;
            if (rdbtnA.Checked)
            {
                option = 1;
                return option;
            }
            if (rdbtnB.Checked)
            {
                option=2;
                return option;
            }
            if (rdbtnC.Checked)
            {
                option=3;
                return option;
            }
            if (rdbtnD.Checked)
            {
                option=4;
                return option;
            }
            return option;
        }
        private int checkRadioBoxes()
        {
            int counter = 0;
            if(rdbtnA.Checked)
            {
                counter++;
            }
            if(rdbtnB.Checked)
            {
                counter++;
            }
            if(rdbtnC.Checked)
            {
                counter++;
            }
            if(rdbtnD.Checked)
            {
                counter++;
            }
            return counter;
        }
        private void btnAdd_Click(object sender, EventArgs e)
        {
            if(rchtxtbxQuestion.Text==String.Empty)
            {
                MessageBox.Show("Please enter the question", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if(txtbxOptionA.Text==string.Empty)
            {
                MessageBox.Show("Please enter option a", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (txtbxOptionB.Text == string.Empty)
            {
                MessageBox.Show("Please enter option b", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (txtbxOptC.Text == string.Empty)
            {
                MessageBox.Show("Please enter option c", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (txtbxOptD.Text == string.Empty)
            {
                MessageBox.Show("Please enter option d", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if(checkRadioBoxes()!=1)
            {
                MessageBox.Show("Please select the correct answer", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            string query = "INSERT INTO `questions_papers`(`question`, `firstoption`, `secondoption`, `thirdoption`, `fourthoption`,`rightanswer`) VALUES (@question,@first,@second,@third,@fourth,@correct)";
            string connectionString = globalVar.CONNECTION_STRING.Replace(globalVar.SERVER_PARAMS, globalVar.SERVER_IP);
            using (MySqlConnection databaseConnection = new MySqlConnection(connectionString))
            {
                databaseConnection.Open();
                MySqlCommand cmd = databaseConnection.CreateCommand();
                cmd.CommandText = query;
                cmd.Parameters.AddWithValue("@question", rchtxtbxQuestion.Text);
                cmd.Parameters.AddWithValue("@first", txtbxOptionA.Text);
                cmd.Parameters.AddWithValue("@second", txtbxOptionB.Text);
                cmd.Parameters.AddWithValue("@third", txtbxOptC.Text);
                cmd.Parameters.AddWithValue("@fourth", txtbxOptD.Text);
                cmd.Parameters.AddWithValue("@correct", optionSelected());
                cmd.ExecuteNonQuery();
                databaseConnection.Close();
            }
            MessageBox.Show("Added to database", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
            reset();
            frmAdmin.loadGrid();
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            reset();
            MessageBox.Show("Reset done successfully", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
