﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Abs_academy_demo_application
{
    public partial class frmStudent : Form
    {
        public frmStudent()
        {
            InitializeComponent();
        }
        int ans1, ans2, ans3, ans4;
        DataTable dt = new DataTable();
        
        private void rdbtnOption1A_CheckedChanged(object sender, EventArgs e)
        {
            if(rdbtnOption1A.Checked)
            {
                ans1 = 1;
            }
            else
            {
                ans1 = 0;
            }
        }

        private void rdbtnOption1B_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbtnOption1B.Checked)
            {
                ans1 = 2;
            }
            else
            {
                ans1 = 0;
            }
        }

        private void rdbtnOption1C_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbtnOption1C.Checked)
            {
                ans1 = 3;
            }
            else
            {
                ans1 = 0;
            }
        }

        private void rdbtnOption1D_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbtnOption1D.Checked)
            {
                ans1 = 4;
            }
            else
            {
                ans1 = 0;
            }
        }

        private void rdbtnOption2A_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbtnOption2A.Checked)
            {
                ans2 = 1;
            }
            else
            {
                ans2 = 0;
            }
        }

        private void rdbtnOption2B_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbtnOption2B.Checked)
            {
                ans2 = 2;
            }
            else
            {
                ans2 = 0;
            }
        }

        private void rdbtnOption2C_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbtnOption2C.Checked)
            {
                ans2 = 3;
            }
            else
            {
                ans2 = 0;
            }
        }

        private void rdbtnOption2D_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbtnOption2D.Checked)
            {
                ans2 = 4;
            }
            else
            {
                ans2 = 0;
            }
        }

        private void rdbtnOption3A_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbtnOption3A.Checked)
            {
                ans3 = 1;
            }
            else
            {
                ans3 = 0;
            }
        }

        private void rdbtnOption3B_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbtnOption3B.Checked)
            {
                ans3 = 2;
            }
            else
            {
                ans3 = 0;
            }
        }

        private void rdbtnOption3C_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbtnOption3C.Checked)
            {
                ans3 = 3;
            }
            else
            {
                ans3 = 0;
            }
        }

        private void rdbtnOption3D_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbtnOption3D.Checked)
            {
                ans3 = 4;
            }
            else
            {
                ans3 = 0;
            }
        }

        private void rdbtnOption4A_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbtnOption4A.Checked)
            {
                ans4 = 1;
            }
            else
            {
                ans4 = 0;
            }
        }

        private void rdbtnOption4B_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbtnOption4B.Checked)
            {
                ans4 = 2;
            }
            else
            {
                ans4 = 0;
            }
        }

        private void rdbtnOption4C_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbtnOption4C.Checked)
            {
                ans4 = 3;
            }
            else
            {
                ans4 = 0;
            }
        }

        private void rdbtnOption4D_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbtnOption4D.Checked)
            {
                ans4 = 4;
            }
            else
            {
                ans4 = 0;
            }
        }

        private int marksCounter()
        {
            int marks = 0;
            if(ans1.ToString()==lblAns1.Text)
            {
                marks++;
            }
            if(ans2.ToString()==lblAns2.Text)
            {
                marks++;
            }
            if(ans3.ToString()==lblAns3.Text)
            {
                marks++;
            }
            if(ans4.ToString()==lblAns4.Text)
            {
                marks++;
            }
            return marks;
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            string query = "INSERT INTO `results`(`Name of student`, `Marks`, `Date`) VALUES (@name,@marks,@date)";
            string connectionString = globalVar.CONNECTION_STRING.Replace(globalVar.SERVER_PARAMS, globalVar.SERVER_IP);
            using (MySqlConnection databaseConnection = new MySqlConnection(connectionString))
            {
                databaseConnection.Open();
                MySqlCommand cmd = databaseConnection.CreateCommand();
                cmd.CommandText = query;
                cmd.Parameters.AddWithValue("@name", "Demouser");
                cmd.Parameters.AddWithValue("@marks", marksCounter().ToString());
                cmd.Parameters.AddWithValue("@date", DateTime.Now.ToString());
                cmd.ExecuteNonQuery();
                databaseConnection.Close();
            }
            MessageBox.Show("Results are saved to database \n go admin panel to view result",Application.ProductName,MessageBoxButtons.OK,MessageBoxIcon.Information);
        }

        private void frmStudent_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
        private void loadScreen()
        {
            string query = "SELECT * FROM  `questions_papers` LIMIT 4";
            string connectionString = globalVar.CONNECTION_STRING.Replace(globalVar.SERVER_PARAMS, globalVar.SERVER_IP);
            using (MySqlConnection databaseConnection = new MySqlConnection(connectionString))
            {
                databaseConnection.Open();
                MySqlCommand cmd = new MySqlCommand(query, databaseConnection);
                MySqlDataAdapter adapter = new MySqlDataAdapter();
                adapter.SelectCommand = cmd;
                adapter.Fill(dt);
                databaseConnection.Close();
            }
            lblQ1.Text = $"Q{dt.Rows[0][0]}.";
            lblQ2.Text = $"Q{dt.Rows[1][0]}.";
            lblQ3.Text = $"Q{dt.Rows[2][0]}.";
            lblQ4.Text = $"Q{dt.Rows[3][0]}.";
            lblQuestion1.Text = dt.Rows[0][1].ToString();
            lblQuestion2.Text = dt.Rows[1][1].ToString();
            lblQuestion3.Text = dt.Rows[2][1].ToString();
            lblQuestion4.Text = dt.Rows[3][1].ToString();
            rdbtnOption1A.Text = dt.Rows[0][2].ToString();
            rdbtnOption1B.Text = dt.Rows[0][3].ToString();
            rdbtnOption1C.Text = dt.Rows[0][4].ToString();
            rdbtnOption1D.Text = dt.Rows[0][5].ToString();
            lblAns1.Text= dt.Rows[0][6].ToString();
            rdbtnOption2A.Text = dt.Rows[1][2].ToString();
            rdbtnOption2B.Text = dt.Rows[1][3].ToString();
            rdbtnOption2C.Text = dt.Rows[1][4].ToString();
            rdbtnOption2D.Text = dt.Rows[1][5].ToString();
            lblAns2.Text = dt.Rows[1][6].ToString();
            rdbtnOption3A.Text = dt.Rows[2][2].ToString();
            rdbtnOption3B.Text = dt.Rows[2][3].ToString();
            rdbtnOption3C.Text = dt.Rows[2][4].ToString();
            rdbtnOption3D.Text = dt.Rows[2][5].ToString();
            lblAns3.Text = dt.Rows[2][6].ToString();
            rdbtnOption4A.Text = dt.Rows[3][2].ToString();
            rdbtnOption4B.Text = dt.Rows[3][3].ToString();
            rdbtnOption4C.Text = dt.Rows[3][4].ToString();
            rdbtnOption4D.Text = dt.Rows[3][5].ToString();
            lblAns4.Text = dt.Rows[3][6].ToString();
        }
        private void frmStudent_Load(object sender, EventArgs e)
        {
            loadScreen();
        }
    }
}
