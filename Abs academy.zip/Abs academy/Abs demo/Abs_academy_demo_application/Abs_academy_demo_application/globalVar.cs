﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Abs_academy_demo_application
{
    class globalVar
    {
        public static string CONNECTION_STRING = "datasource=$serverIp$;port=3306;username=root;password=;database=abs_demo_data_db;";
        public static string SERVER_IP = "";
        public static string SERVER_PARAMS = "$serverIp$";
    }
}
