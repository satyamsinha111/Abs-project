﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Abs_academy_demo_application
{
    public partial class frmConfigure : Form
    {
        public frmConfigure()
        {
            InitializeComponent();
        }
        bool isTested = false;
        private void frmConfigure_Load(object sender, EventArgs e)
        {

        }

        private void btnTest_Click(object sender, EventArgs e)
        {
            string serverIp = txtbxIp.Text;
            string databaseName = txtbxDatabseName.Text;
            globalVar.SERVER_IP = serverIp;
            string connectionString = globalVar.CONNECTION_STRING.Replace(globalVar.SERVER_PARAMS, serverIp);
            using(MySqlConnection databaseConnection = new MySqlConnection(connectionString))
            {
                databaseConnection.Open();
                if(databaseConnection.State.ToString()=="Open")
                {
                    MessageBox.Show("Database verified", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    isTested = true;
                }
                else
                {
                    isTested = false;
                }
                databaseConnection.Close();
            }
        }

        private void btnProceed_Click(object sender, EventArgs e)
        {
            if(isTested)
            {
                this.Hide();
                frmLogin frmLogin = new frmLogin();
                frmLogin.ShowDialog();
            }
            else
            {
                MessageBox.Show("Database is not verified", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
    }
}
