﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Abs_academy_demo_application
{
    public partial class frmLogin : Form
    {
        public frmLogin()
        {
            InitializeComponent();
        }
        private void reset()
        {
            
        }
        private void frmLogin_Load(object sender, EventArgs e)
        {
            
        }

        private void frmLogin_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            
            //student virtual login
            if(txtbxUsername.Text=="Student" && txtbxPassword.Text=="1234")
            {
                this.Hide();
                frmStudent frmStudent = new frmStudent();
                frmStudent.ShowDialog();
                return;
            }
            else if(txtbxUsername.Text=="Teacher" && txtbxPassword.Text=="1234")
            {
                this.Hide();
                frmAdmin frmAdmin = new frmAdmin();
                frmAdmin.ShowDialog();
                return;
            }
            else
            {
                MessageBox.Show("Wrong password", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
    }
}
