﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Abs_academy_demo_application
{
    public partial class frmAdmin : Form
    {
        public frmAdmin()
        {
            InitializeComponent();
        }

        private void frmAdmin_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void btnAddQuestion_Click(object sender, EventArgs e)
        {
            loadGrid();
            frmQuestion frmQuestion = new frmQuestion(this);
            frmQuestion.ShowDialog();
        }

        public void loadGrid()
        {
            string query = "SELECT * FROM  `questions_papers`";
            string connectionString = globalVar.CONNECTION_STRING.Replace(globalVar.SERVER_PARAMS, globalVar.SERVER_IP);
            using (MySqlConnection databaseConnection = new MySqlConnection(connectionString))
            {
                databaseConnection.Open();
                MySqlCommand cmd = new MySqlCommand(query, databaseConnection);
                MySqlDataAdapter adapter = new MySqlDataAdapter();
                adapter.SelectCommand = cmd;
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                dgvQuestions.DataSource = dt;
                databaseConnection.Close();
            }
        }
        private void frmAdmin_Load(object sender, EventArgs e)
        {
            loadGrid();
        }

        private void btnResult_Click(object sender, EventArgs e)
        {
            string query = "SELECT * FROM  `results`";
            string connectionString = globalVar.CONNECTION_STRING.Replace(globalVar.SERVER_PARAMS, globalVar.SERVER_IP);
            using (MySqlConnection databaseConnection = new MySqlConnection(connectionString))
            {
                databaseConnection.Open();
                MySqlCommand cmd = new MySqlCommand(query, databaseConnection);
                MySqlDataAdapter adapter = new MySqlDataAdapter();
                adapter.SelectCommand = cmd;
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                dgvQuestions.DataSource = dt;
                databaseConnection.Close();
            }
        }
    }
}
