﻿namespace Abs_academy_demo_application
{
    partial class frmStudent
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmStudent));
            this.panel1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.lblQ1 = new System.Windows.Forms.Label();
            this.lblQuestion1 = new System.Windows.Forms.Label();
            this.lblQuestion2 = new System.Windows.Forms.Label();
            this.lblQ2 = new System.Windows.Forms.Label();
            this.lblQuestion3 = new System.Windows.Forms.Label();
            this.lblQ3 = new System.Windows.Forms.Label();
            this.lblQuestion4 = new System.Windows.Forms.Label();
            this.lblQ4 = new System.Windows.Forms.Label();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblAns1 = new System.Windows.Forms.Label();
            this.rdbtnOption1B = new System.Windows.Forms.RadioButton();
            this.rdbtnOption1C = new System.Windows.Forms.RadioButton();
            this.rdbtnOption1D = new System.Windows.Forms.RadioButton();
            this.rdbtnOption1A = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lblAns2 = new System.Windows.Forms.Label();
            this.rdbtnOption2B = new System.Windows.Forms.RadioButton();
            this.rdbtnOption2C = new System.Windows.Forms.RadioButton();
            this.rdbtnOption2D = new System.Windows.Forms.RadioButton();
            this.rdbtnOption2A = new System.Windows.Forms.RadioButton();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.lblAns3 = new System.Windows.Forms.Label();
            this.rdbtnOption3B = new System.Windows.Forms.RadioButton();
            this.rdbtnOption3C = new System.Windows.Forms.RadioButton();
            this.rdbtnOption3D = new System.Windows.Forms.RadioButton();
            this.rdbtnOption3A = new System.Windows.Forms.RadioButton();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.lblAns4 = new System.Windows.Forms.Label();
            this.rdbtnOption4B = new System.Windows.Forms.RadioButton();
            this.rdbtnOption4C = new System.Windows.Forms.RadioButton();
            this.rdbtnOption4D = new System.Windows.Forms.RadioButton();
            this.rdbtnOption4A = new System.Windows.Forms.RadioButton();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1294, 100);
            this.panel1.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Nirmala UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(151, 61);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(76, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Durgapur ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Nirmala UI", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(136, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(622, 37);
            this.label1.TabIndex = 1;
            this.label1.Text = "Abs academy science technology and management";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 8);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 85);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.GrayText;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel2.Location = new System.Drawing.Point(1049, 100);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(245, 634);
            this.panel2.TabIndex = 2;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.GrayText;
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel3.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel3.Location = new System.Drawing.Point(0, 100);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(276, 634);
            this.panel3.TabIndex = 3;
            // 
            // lblQ1
            // 
            this.lblQ1.AutoSize = true;
            this.lblQ1.Font = new System.Drawing.Font("Nirmala UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ1.Location = new System.Drawing.Point(311, 105);
            this.lblQ1.Name = "lblQ1";
            this.lblQ1.Size = new System.Drawing.Size(28, 20);
            this.lblQ1.TabIndex = 4;
            this.lblQ1.Text = "Q .";
            // 
            // lblQuestion1
            // 
            this.lblQuestion1.Font = new System.Drawing.Font("Nirmala UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuestion1.Location = new System.Drawing.Point(345, 105);
            this.lblQuestion1.Name = "lblQuestion1";
            this.lblQuestion1.Size = new System.Drawing.Size(662, 25);
            this.lblQuestion1.TabIndex = 5;
            this.lblQuestion1.Text = "What is the capital of India ?";
            // 
            // lblQuestion2
            // 
            this.lblQuestion2.Font = new System.Drawing.Font("Nirmala UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuestion2.Location = new System.Drawing.Point(345, 234);
            this.lblQuestion2.Name = "lblQuestion2";
            this.lblQuestion2.Size = new System.Drawing.Size(671, 25);
            this.lblQuestion2.TabIndex = 11;
            this.lblQuestion2.Text = "What is the capital of India ?";
            // 
            // lblQ2
            // 
            this.lblQ2.AutoSize = true;
            this.lblQ2.Font = new System.Drawing.Font("Nirmala UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ2.Location = new System.Drawing.Point(311, 234);
            this.lblQ2.Name = "lblQ2";
            this.lblQ2.Size = new System.Drawing.Size(28, 20);
            this.lblQ2.TabIndex = 10;
            this.lblQ2.Text = "Q .";
            // 
            // lblQuestion3
            // 
            this.lblQuestion3.Font = new System.Drawing.Font("Nirmala UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuestion3.Location = new System.Drawing.Point(343, 367);
            this.lblQuestion3.Name = "lblQuestion3";
            this.lblQuestion3.Size = new System.Drawing.Size(673, 25);
            this.lblQuestion3.TabIndex = 17;
            this.lblQuestion3.Text = "What is the capital of India ?";
            // 
            // lblQ3
            // 
            this.lblQ3.AutoSize = true;
            this.lblQ3.Font = new System.Drawing.Font("Nirmala UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ3.Location = new System.Drawing.Point(309, 367);
            this.lblQ3.Name = "lblQ3";
            this.lblQ3.Size = new System.Drawing.Size(28, 20);
            this.lblQ3.TabIndex = 16;
            this.lblQ3.Text = "Q .";
            // 
            // lblQuestion4
            // 
            this.lblQuestion4.Font = new System.Drawing.Font("Nirmala UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuestion4.Location = new System.Drawing.Point(342, 501);
            this.lblQuestion4.Name = "lblQuestion4";
            this.lblQuestion4.Size = new System.Drawing.Size(677, 25);
            this.lblQuestion4.TabIndex = 23;
            this.lblQuestion4.Text = "What is the capital of India ?";
            // 
            // lblQ4
            // 
            this.lblQ4.AutoSize = true;
            this.lblQ4.Font = new System.Drawing.Font("Nirmala UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ4.Location = new System.Drawing.Point(308, 501);
            this.lblQ4.Name = "lblQ4";
            this.lblQ4.Size = new System.Drawing.Size(28, 20);
            this.lblQ4.TabIndex = 22;
            this.lblQ4.Text = "Q .";
            // 
            // btnSubmit
            // 
            this.btnSubmit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSubmit.Font = new System.Drawing.Font("Nirmala UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubmit.Location = new System.Drawing.Point(888, 675);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(131, 39);
            this.btnSubmit.TabIndex = 28;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.lblAns1);
            this.groupBox1.Controls.Add(this.rdbtnOption1B);
            this.groupBox1.Controls.Add(this.rdbtnOption1C);
            this.groupBox1.Controls.Add(this.rdbtnOption1D);
            this.groupBox1.Controls.Add(this.rdbtnOption1A);
            this.groupBox1.Location = new System.Drawing.Point(320, 128);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(696, 100);
            this.groupBox1.TabIndex = 29;
            this.groupBox1.TabStop = false;
            // 
            // lblAns1
            // 
            this.lblAns1.AutoSize = true;
            this.lblAns1.Location = new System.Drawing.Point(337, 53);
            this.lblAns1.Name = "lblAns1";
            this.lblAns1.Size = new System.Drawing.Size(38, 13);
            this.lblAns1.TabIndex = 15;
            this.lblAns1.Text = "label4";
            this.lblAns1.Visible = false;
            // 
            // rdbtnOption1B
            // 
            this.rdbtnOption1B.AutoSize = true;
            this.rdbtnOption1B.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbtnOption1B.Location = new System.Drawing.Point(559, 24);
            this.rdbtnOption1B.Name = "rdbtnOption1B";
            this.rdbtnOption1B.Size = new System.Drawing.Size(119, 25);
            this.rdbtnOption1B.TabIndex = 13;
            this.rdbtnOption1B.TabStop = true;
            this.rdbtnOption1B.Text = "radioButton4";
            this.rdbtnOption1B.UseVisualStyleBackColor = true;
            this.rdbtnOption1B.CheckedChanged += new System.EventHandler(this.rdbtnOption1B_CheckedChanged);
            // 
            // rdbtnOption1C
            // 
            this.rdbtnOption1C.AutoSize = true;
            this.rdbtnOption1C.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbtnOption1C.Location = new System.Drawing.Point(19, 53);
            this.rdbtnOption1C.Name = "rdbtnOption1C";
            this.rdbtnOption1C.Size = new System.Drawing.Size(119, 25);
            this.rdbtnOption1C.TabIndex = 12;
            this.rdbtnOption1C.TabStop = true;
            this.rdbtnOption1C.Text = "radioButton3";
            this.rdbtnOption1C.UseVisualStyleBackColor = true;
            this.rdbtnOption1C.CheckedChanged += new System.EventHandler(this.rdbtnOption1C_CheckedChanged);
            // 
            // rdbtnOption1D
            // 
            this.rdbtnOption1D.AutoSize = true;
            this.rdbtnOption1D.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbtnOption1D.Location = new System.Drawing.Point(559, 61);
            this.rdbtnOption1D.Name = "rdbtnOption1D";
            this.rdbtnOption1D.Size = new System.Drawing.Size(119, 25);
            this.rdbtnOption1D.TabIndex = 11;
            this.rdbtnOption1D.TabStop = true;
            this.rdbtnOption1D.Text = "radioButton2";
            this.rdbtnOption1D.UseVisualStyleBackColor = true;
            this.rdbtnOption1D.CheckedChanged += new System.EventHandler(this.rdbtnOption1D_CheckedChanged);
            // 
            // rdbtnOption1A
            // 
            this.rdbtnOption1A.AutoSize = true;
            this.rdbtnOption1A.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbtnOption1A.Location = new System.Drawing.Point(19, 15);
            this.rdbtnOption1A.Name = "rdbtnOption1A";
            this.rdbtnOption1A.Size = new System.Drawing.Size(119, 25);
            this.rdbtnOption1A.TabIndex = 10;
            this.rdbtnOption1A.TabStop = true;
            this.rdbtnOption1A.Text = "radioButton1";
            this.rdbtnOption1A.UseVisualStyleBackColor = true;
            this.rdbtnOption1A.CheckedChanged += new System.EventHandler(this.rdbtnOption1A_CheckedChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.Controls.Add(this.lblAns2);
            this.groupBox2.Controls.Add(this.rdbtnOption2B);
            this.groupBox2.Controls.Add(this.rdbtnOption2C);
            this.groupBox2.Controls.Add(this.rdbtnOption2D);
            this.groupBox2.Controls.Add(this.rdbtnOption2A);
            this.groupBox2.Location = new System.Drawing.Point(320, 262);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(696, 100);
            this.groupBox2.TabIndex = 30;
            this.groupBox2.TabStop = false;
            // 
            // lblAns2
            // 
            this.lblAns2.AutoSize = true;
            this.lblAns2.Location = new System.Drawing.Point(337, 41);
            this.lblAns2.Name = "lblAns2";
            this.lblAns2.Size = new System.Drawing.Size(38, 13);
            this.lblAns2.TabIndex = 14;
            this.lblAns2.Text = "label3";
            this.lblAns2.Visible = false;
            // 
            // rdbtnOption2B
            // 
            this.rdbtnOption2B.AutoSize = true;
            this.rdbtnOption2B.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbtnOption2B.Location = new System.Drawing.Point(559, 24);
            this.rdbtnOption2B.Name = "rdbtnOption2B";
            this.rdbtnOption2B.Size = new System.Drawing.Size(128, 25);
            this.rdbtnOption2B.TabIndex = 13;
            this.rdbtnOption2B.TabStop = true;
            this.rdbtnOption2B.Text = "radioButton17";
            this.rdbtnOption2B.UseVisualStyleBackColor = true;
            this.rdbtnOption2B.CheckedChanged += new System.EventHandler(this.rdbtnOption2B_CheckedChanged);
            // 
            // rdbtnOption2C
            // 
            this.rdbtnOption2C.AutoSize = true;
            this.rdbtnOption2C.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbtnOption2C.Location = new System.Drawing.Point(19, 53);
            this.rdbtnOption2C.Name = "rdbtnOption2C";
            this.rdbtnOption2C.Size = new System.Drawing.Size(128, 25);
            this.rdbtnOption2C.TabIndex = 12;
            this.rdbtnOption2C.TabStop = true;
            this.rdbtnOption2C.Text = "radioButton18";
            this.rdbtnOption2C.UseVisualStyleBackColor = true;
            this.rdbtnOption2C.CheckedChanged += new System.EventHandler(this.rdbtnOption2C_CheckedChanged);
            // 
            // rdbtnOption2D
            // 
            this.rdbtnOption2D.AutoSize = true;
            this.rdbtnOption2D.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbtnOption2D.Location = new System.Drawing.Point(559, 61);
            this.rdbtnOption2D.Name = "rdbtnOption2D";
            this.rdbtnOption2D.Size = new System.Drawing.Size(128, 25);
            this.rdbtnOption2D.TabIndex = 11;
            this.rdbtnOption2D.TabStop = true;
            this.rdbtnOption2D.Text = "radioButton19";
            this.rdbtnOption2D.UseVisualStyleBackColor = true;
            this.rdbtnOption2D.CheckedChanged += new System.EventHandler(this.rdbtnOption2D_CheckedChanged);
            // 
            // rdbtnOption2A
            // 
            this.rdbtnOption2A.AutoSize = true;
            this.rdbtnOption2A.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbtnOption2A.Location = new System.Drawing.Point(19, 15);
            this.rdbtnOption2A.Name = "rdbtnOption2A";
            this.rdbtnOption2A.Size = new System.Drawing.Size(128, 25);
            this.rdbtnOption2A.TabIndex = 10;
            this.rdbtnOption2A.TabStop = true;
            this.rdbtnOption2A.Text = "radioButton20";
            this.rdbtnOption2A.UseVisualStyleBackColor = true;
            this.rdbtnOption2A.CheckedChanged += new System.EventHandler(this.rdbtnOption2A_CheckedChanged);
            // 
            // groupBox3
            // 
            this.groupBox3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox3.Controls.Add(this.lblAns3);
            this.groupBox3.Controls.Add(this.rdbtnOption3B);
            this.groupBox3.Controls.Add(this.rdbtnOption3C);
            this.groupBox3.Controls.Add(this.rdbtnOption3D);
            this.groupBox3.Controls.Add(this.rdbtnOption3A);
            this.groupBox3.Location = new System.Drawing.Point(320, 395);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(696, 100);
            this.groupBox3.TabIndex = 31;
            this.groupBox3.TabStop = false;
            // 
            // lblAns3
            // 
            this.lblAns3.AutoSize = true;
            this.lblAns3.Location = new System.Drawing.Point(337, 53);
            this.lblAns3.Name = "lblAns3";
            this.lblAns3.Size = new System.Drawing.Size(38, 13);
            this.lblAns3.TabIndex = 15;
            this.lblAns3.Text = "label5";
            this.lblAns3.Visible = false;
            // 
            // rdbtnOption3B
            // 
            this.rdbtnOption3B.AutoSize = true;
            this.rdbtnOption3B.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbtnOption3B.Location = new System.Drawing.Point(559, 24);
            this.rdbtnOption3B.Name = "rdbtnOption3B";
            this.rdbtnOption3B.Size = new System.Drawing.Size(119, 25);
            this.rdbtnOption3B.TabIndex = 13;
            this.rdbtnOption3B.TabStop = true;
            this.rdbtnOption3B.Text = "radioButton5";
            this.rdbtnOption3B.UseVisualStyleBackColor = true;
            this.rdbtnOption3B.CheckedChanged += new System.EventHandler(this.rdbtnOption3B_CheckedChanged);
            // 
            // rdbtnOption3C
            // 
            this.rdbtnOption3C.AutoSize = true;
            this.rdbtnOption3C.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbtnOption3C.Location = new System.Drawing.Point(19, 53);
            this.rdbtnOption3C.Name = "rdbtnOption3C";
            this.rdbtnOption3C.Size = new System.Drawing.Size(119, 25);
            this.rdbtnOption3C.TabIndex = 12;
            this.rdbtnOption3C.TabStop = true;
            this.rdbtnOption3C.Text = "radioButton6";
            this.rdbtnOption3C.UseVisualStyleBackColor = true;
            this.rdbtnOption3C.CheckedChanged += new System.EventHandler(this.rdbtnOption3C_CheckedChanged);
            // 
            // rdbtnOption3D
            // 
            this.rdbtnOption3D.AutoSize = true;
            this.rdbtnOption3D.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbtnOption3D.Location = new System.Drawing.Point(559, 61);
            this.rdbtnOption3D.Name = "rdbtnOption3D";
            this.rdbtnOption3D.Size = new System.Drawing.Size(119, 25);
            this.rdbtnOption3D.TabIndex = 11;
            this.rdbtnOption3D.TabStop = true;
            this.rdbtnOption3D.Text = "radioButton7";
            this.rdbtnOption3D.UseVisualStyleBackColor = true;
            this.rdbtnOption3D.CheckedChanged += new System.EventHandler(this.rdbtnOption3D_CheckedChanged);
            // 
            // rdbtnOption3A
            // 
            this.rdbtnOption3A.AutoSize = true;
            this.rdbtnOption3A.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbtnOption3A.Location = new System.Drawing.Point(19, 15);
            this.rdbtnOption3A.Name = "rdbtnOption3A";
            this.rdbtnOption3A.Size = new System.Drawing.Size(119, 25);
            this.rdbtnOption3A.TabIndex = 10;
            this.rdbtnOption3A.TabStop = true;
            this.rdbtnOption3A.Text = "radioButton8";
            this.rdbtnOption3A.UseVisualStyleBackColor = true;
            this.rdbtnOption3A.CheckedChanged += new System.EventHandler(this.rdbtnOption3A_CheckedChanged);
            // 
            // groupBox4
            // 
            this.groupBox4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox4.Controls.Add(this.lblAns4);
            this.groupBox4.Controls.Add(this.rdbtnOption4B);
            this.groupBox4.Controls.Add(this.rdbtnOption4C);
            this.groupBox4.Controls.Add(this.rdbtnOption4D);
            this.groupBox4.Controls.Add(this.rdbtnOption4A);
            this.groupBox4.Location = new System.Drawing.Point(320, 542);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(696, 100);
            this.groupBox4.TabIndex = 32;
            this.groupBox4.TabStop = false;
            // 
            // lblAns4
            // 
            this.lblAns4.AutoSize = true;
            this.lblAns4.Location = new System.Drawing.Point(327, 53);
            this.lblAns4.Name = "lblAns4";
            this.lblAns4.Size = new System.Drawing.Size(38, 13);
            this.lblAns4.TabIndex = 16;
            this.lblAns4.Text = "label6";
            this.lblAns4.Visible = false;
            // 
            // rdbtnOption4B
            // 
            this.rdbtnOption4B.AutoSize = true;
            this.rdbtnOption4B.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbtnOption4B.Location = new System.Drawing.Point(559, 24);
            this.rdbtnOption4B.Name = "rdbtnOption4B";
            this.rdbtnOption4B.Size = new System.Drawing.Size(119, 25);
            this.rdbtnOption4B.TabIndex = 13;
            this.rdbtnOption4B.TabStop = true;
            this.rdbtnOption4B.Text = "radioButton9";
            this.rdbtnOption4B.UseVisualStyleBackColor = true;
            this.rdbtnOption4B.CheckedChanged += new System.EventHandler(this.rdbtnOption4B_CheckedChanged);
            // 
            // rdbtnOption4C
            // 
            this.rdbtnOption4C.AutoSize = true;
            this.rdbtnOption4C.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbtnOption4C.Location = new System.Drawing.Point(19, 53);
            this.rdbtnOption4C.Name = "rdbtnOption4C";
            this.rdbtnOption4C.Size = new System.Drawing.Size(128, 25);
            this.rdbtnOption4C.TabIndex = 12;
            this.rdbtnOption4C.TabStop = true;
            this.rdbtnOption4C.Text = "radioButton10";
            this.rdbtnOption4C.UseVisualStyleBackColor = true;
            this.rdbtnOption4C.CheckedChanged += new System.EventHandler(this.rdbtnOption4C_CheckedChanged);
            // 
            // rdbtnOption4D
            // 
            this.rdbtnOption4D.AutoSize = true;
            this.rdbtnOption4D.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbtnOption4D.Location = new System.Drawing.Point(559, 61);
            this.rdbtnOption4D.Name = "rdbtnOption4D";
            this.rdbtnOption4D.Size = new System.Drawing.Size(128, 25);
            this.rdbtnOption4D.TabIndex = 11;
            this.rdbtnOption4D.TabStop = true;
            this.rdbtnOption4D.Text = "radioButton11";
            this.rdbtnOption4D.UseVisualStyleBackColor = true;
            this.rdbtnOption4D.CheckedChanged += new System.EventHandler(this.rdbtnOption4D_CheckedChanged);
            // 
            // rdbtnOption4A
            // 
            this.rdbtnOption4A.AutoSize = true;
            this.rdbtnOption4A.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbtnOption4A.Location = new System.Drawing.Point(19, 15);
            this.rdbtnOption4A.Name = "rdbtnOption4A";
            this.rdbtnOption4A.Size = new System.Drawing.Size(128, 25);
            this.rdbtnOption4A.TabIndex = 10;
            this.rdbtnOption4A.TabStop = true;
            this.rdbtnOption4A.Text = "radioButton12";
            this.rdbtnOption4A.UseVisualStyleBackColor = true;
            this.rdbtnOption4A.CheckedChanged += new System.EventHandler(this.rdbtnOption4A_CheckedChanged);
            // 
            // frmStudent
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1294, 734);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.lblQuestion4);
            this.Controls.Add(this.lblQ4);
            this.Controls.Add(this.lblQuestion3);
            this.Controls.Add(this.lblQ3);
            this.Controls.Add(this.lblQuestion2);
            this.Controls.Add(this.lblQ2);
            this.Controls.Add(this.lblQuestion1);
            this.Controls.Add(this.lblQ1);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("Nirmala UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmStudent";
            this.Text = "frmStudent";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmStudent_FormClosing);
            this.Load += new System.EventHandler(this.frmStudent_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label lblQ1;
        private System.Windows.Forms.Label lblQuestion1;
        private System.Windows.Forms.Label lblQuestion2;
        private System.Windows.Forms.Label lblQ2;
        private System.Windows.Forms.Label lblQuestion3;
        private System.Windows.Forms.Label lblQ3;
        private System.Windows.Forms.Label lblQuestion4;
        private System.Windows.Forms.Label lblQ4;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rdbtnOption1B;
        private System.Windows.Forms.RadioButton rdbtnOption1C;
        private System.Windows.Forms.RadioButton rdbtnOption1D;
        private System.Windows.Forms.RadioButton rdbtnOption1A;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton rdbtnOption2B;
        private System.Windows.Forms.RadioButton rdbtnOption2C;
        private System.Windows.Forms.RadioButton rdbtnOption2D;
        private System.Windows.Forms.RadioButton rdbtnOption2A;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.RadioButton rdbtnOption3B;
        private System.Windows.Forms.RadioButton rdbtnOption3C;
        private System.Windows.Forms.RadioButton rdbtnOption3D;
        private System.Windows.Forms.RadioButton rdbtnOption3A;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.RadioButton rdbtnOption4B;
        private System.Windows.Forms.RadioButton rdbtnOption4C;
        private System.Windows.Forms.RadioButton rdbtnOption4D;
        private System.Windows.Forms.RadioButton rdbtnOption4A;
        private System.Windows.Forms.Label lblAns1;
        private System.Windows.Forms.Label lblAns2;
        private System.Windows.Forms.Label lblAns3;
        private System.Windows.Forms.Label lblAns4;
    }
}